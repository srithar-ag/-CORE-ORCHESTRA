import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { INITIAL_PROJECTS, INITIAL_INTERNSHIPS, INITIAL_CERTIFICATES } from './src/data/initialData.ts';
import { Project, Internship, Application, ContactMessage, Certificate } from './src/types.ts';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory data store for server operations
  let projects: Project[] = [...INITIAL_PROJECTS];
  let internships: Internship[] = [...INITIAL_INTERNSHIPS];
  let applications: Application[] = [
    {
      id: 'app-sample-1',
      referenceId: 'DR-2026-8942',
      itemType: 'Project',
      itemId: 'proj-1',
      itemTitle: 'Autonomous Multi-Agent AI System for Financial Forecasting',
      domain: 'Artificial Intelligence',
      status: 'Shortlisted',
      appliedAt: '2026-08-01T14:32:00Z',
      fullName: 'Alex Mercer',
      email: 'student@dotrepo.org',
      phone: '+1 555-0192',
      dob: '2002-04-12',
      gender: 'Male',
      address: 'San Francisco, CA',
      college: 'Stanford University',
      university: 'Stanford',
      degree: 'B.S. Computer Science',
      department: 'EECS',
      year: 'Final Year (2026)',
      cgpa: '3.85',
      programmingLanguages: ['Python', 'C++', 'JavaScript'],
      frameworks: ['PyTorch', 'React', 'FastAPI'],
      databases: ['PostgreSQL', 'ChromaDB'],
      tools: ['Docker', 'Git', 'Linux'],
      softSkills: ['Leadership', 'Problem Solving', 'Communication'],
      projectsExperience: 'Built a transformer-based code translation tool with 92% accuracy.',
      internshipsExperience: 'Software Engineer Intern at Acme AI.',
      githubUrl: 'https://github.com/alexmercer',
      linkedinUrl: 'https://linkedin.com/in/alexmercer',
      portfolioUrl: 'https://alexmercer.dev',
      resumeFileName: 'Alex_Mercer_Resume_2026.pdf',
      whyJoin: 'DotRepo provides unmatched real-world product engineering exposure.',
      whySelectYou: 'I bring deep PyTorch experience and a passion for multi-agent systems.',
      careerGoals: 'To become a Principal AI Systems Architect.',
      availability: 'Immediate (20 hours/week)',
      interviewDetails: {
        date: '2026-08-12',
        time: '11:00 AM PST',
        link: 'https://meet.dotrepo.org/int-8942',
        notes: 'Bring system architecture diagram for agent protocol discussion.'
      },
      adminNotes: 'Strong candidate with impressive PyTorch GitHub projects.'
    }
  ];
  let certificates: Certificate[] = [...INITIAL_CERTIFICATES];
  let contactMessages: ContactMessage[] = [];

  // ==================== API ENDPOINTS ====================

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // --- PROJECTS ---
  app.get('/api/projects', (req, res) => {
    let result = [...projects];
    const { domain, difficulty, duration, search } = req.query;

    if (domain && domain !== 'All') {
      result = result.filter(p => p.domain.toLowerCase() === (domain as string).toLowerCase());
    }
    if (difficulty && difficulty !== 'All') {
      result = result.filter(p => p.difficulty.toLowerCase() === (difficulty as string).toLowerCase());
    }
    if (duration && duration !== 'All') {
      result = result.filter(p => p.duration.toLowerCase() === (duration as string).toLowerCase());
    }
    if (search) {
      const q = (search as string).toLowerCase();
      result = result.filter(
        p =>
          p.name.toLowerCase().includes(q) ||
          p.overview.toLowerCase().includes(q) ||
          p.domain.toLowerCase().includes(q) ||
          p.techStack.some(t => t.toLowerCase().includes(q))
      );
    }

    res.json(result);
  });

  app.get('/api/projects/:id', (req, res) => {
    const proj = projects.find(p => p.id === req.params.id);
    if (!proj) {
      res.status(404).json({ message: 'Project not found' });
      return;
    }
    res.json(proj);
  });

  app.post('/api/projects', (req, res) => {
    const newProj: Project = {
      ...req.body,
      id: `proj-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    projects.unshift(newProj);
    res.status(201).json(newProj);
  });

  app.put('/api/projects/:id', (req, res) => {
    const idx = projects.findIndex(p => p.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ message: 'Project not found' });
      return;
    }
    projects[idx] = { ...projects[idx], ...req.body };
    res.json(projects[idx]);
  });

  app.delete('/api/projects/:id', (req, res) => {
    projects = projects.filter(p => p.id !== req.params.id);
    res.json({ success: true, message: 'Project deleted successfully' });
  });

  // --- INTERNSHIPS ---
  app.get('/api/internships', (req, res) => {
    let result = [...internships];
    const { domain, duration, search } = req.query;

    if (domain && domain !== 'All') {
      result = result.filter(i => i.domain.toLowerCase() === (domain as string).toLowerCase());
    }
    if (duration && duration !== 'All') {
      result = result.filter(i => i.duration.toLowerCase() === (duration as string).toLowerCase());
    }
    if (search) {
      const q = (search as string).toLowerCase();
      result = result.filter(
        i =>
          i.role.toLowerCase().includes(q) ||
          i.company.toLowerCase().includes(q) ||
          i.overview.toLowerCase().includes(q) ||
          i.domain.toLowerCase().includes(q) ||
          i.techStack.some(t => t.toLowerCase().includes(q))
      );
    }

    res.json(result);
  });

  app.get('/api/internships/:id', (req, res) => {
    const intern = internships.find(i => i.id === req.params.id);
    if (!intern) {
      res.status(404).json({ message: 'Internship not found' });
      return;
    }
    res.json(intern);
  });

  app.post('/api/internships', (req, res) => {
    const newIntern: Internship = {
      ...req.body,
      id: `intern-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    internships.unshift(newIntern);
    res.status(201).json(newIntern);
  });

  app.put('/api/internships/:id', (req, res) => {
    const idx = internships.findIndex(i => i.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ message: 'Internship not found' });
      return;
    }
    internships[idx] = { ...internships[idx], ...req.body };
    res.json(internships[idx]);
  });

  app.delete('/api/internships/:id', (req, res) => {
    internships = internships.filter(i => i.id !== req.params.id);
    res.json({ success: true, message: 'Internship deleted' });
  });

  // --- APPLICATIONS ---
  app.post('/api/applications', (req, res) => {
    const refCode = `DR-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newApp: Application = {
      ...req.body,
      id: `app-${Date.now()}`,
      referenceId: refCode,
      status: 'Applied',
      appliedAt: new Date().toISOString()
    };
    applications.unshift(newApp);
    res.status(201).json({
      success: true,
      message: 'Application submitted successfully',
      referenceId: refCode,
      application: newApp
    });
  });

  app.get('/api/applications', (req, res) => {
    const { email, referenceId } = req.query;
    let result = [...applications];

    if (email) {
      result = result.filter(a => a.email.toLowerCase() === (email as string).toLowerCase());
    }
    if (referenceId) {
      result = result.filter(a => a.referenceId.toUpperCase() === (referenceId as string).toUpperCase());
    }

    res.json(result);
  });

  app.patch('/api/applications/:id/status', (req, res) => {
    const { status, interviewDetails, adminNotes } = req.body;
    const appItem = applications.find(a => a.id === req.params.id);
    if (!appItem) {
      res.status(404).json({ message: 'Application not found' });
      return;
    }

    if (status) appItem.status = status;
    if (interviewDetails) appItem.interviewDetails = interviewDetails;
    if (adminNotes !== undefined) appItem.adminNotes = adminNotes;

    res.json({ success: true, application: appItem });
  });

  // --- AUTH ---
  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    
    if (email === 'admin@dotrepo.org' || email === 'admin') {
      res.json({
        token: 'jwt-mock-admin-token-dotrepo-secret',
        user: {
          id: 'usr-admin',
          name: 'Admin Command',
          email: 'admin@dotrepo.org',
          role: 'admin',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop',
          bio: 'DotRepo Core Operations Lead'
        }
      });
      return;
    }

    // Standard student login / auto-register
    res.json({
      token: `jwt-mock-student-token-${Date.now()}`,
      user: {
        id: 'usr-student-1',
        name: email ? email.split('@')[0] : 'Alex Mercer',
        email: email || 'student@dotrepo.org',
        role: 'student',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=200&auto=format&fit=crop',
        college: 'Stanford University',
        degree: 'B.S. Computer Science',
        cgpa: '3.85',
        github: 'https://github.com/alexmercer',
        linkedin: 'https://linkedin.com/in/alexmercer',
        bio: 'Passionate full-stack developer focusing on AI systems and UI design.'
      }
    });
  });

  // --- CERTIFICATES ---
  app.get('/api/certificates/verify/:code', (req, res) => {
    const cert = certificates.find(
      c => c.certificateNumber.toUpperCase() === req.params.code.toUpperCase()
    );
    if (!cert) {
      res.status(404).json({ valid: false, message: 'Invalid or expired certificate code' });
      return;
    }
    res.json({ valid: true, certificate: cert });
  });

  // --- CONTACT ---
  app.post('/api/contact', (req, res) => {
    const { name, email, subject, message } = req.body;
    const msg: ContactMessage = {
      id: `msg-${Date.now()}`,
      name,
      email,
      subject,
      message,
      createdAt: new Date().toISOString()
    };
    contactMessages.push(msg);
    res.json({ success: true, message: 'Thank you! Your message has been received by DotRepo team.' });
  });

  // ==================== VITE / STATIC SERVING ====================

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DotRepo Server running on http://localhost:${PORT}`);
  });
}

startServer();
