import { Project, Internship, Certificate, TeamMember, Testimonial, FAQItem } from '../types';

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'proj-1',
    name: 'Autonomous Multi-Agent AI System for Financial Forecasting',
    domain: 'Artificial Intelligence',
    difficulty: 'Advanced',
    duration: '2 Months',
    timeline: '8 Weeks (Phase 1 to Phase 4)',
    mode: 'Remote',
    teamSize: '3-4 Students',
    techStack: ['Python', 'PyTorch', 'LangChain', 'FastAPI', 'React', 'Tailwind'],
    hasCertificate: true,
    isPortfolioProject: true,
    deadline: '2026-08-30',
    thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=800&auto=format&fit=crop',
    overview: 'Build an autonomous agentic framework that analyzes real-time market feeds, SEC filings, and sentiment indicators to construct risk-adjusted portfolio recommendations.',
    description: 'In this high-impact industry project, students will architect an enterprise-grade agent orchestration workflow using Python, LangChain, and PyTorch. You will fine-tune open-weights LLMs for financial named-entity recognition and produce interactive dashboards for real-time visualization.',
    learningOutcomes: [
      'Master agentic workflow orchestration and multi-agent debate protocols',
      'Implement Vector DB retrieval-augmented generation (RAG) with milvus/chroma',
      'Deploy high-throughput FastAPI endpoints with Docker and Kubernetes',
      'Build institutional-grade financial telemetry UI in React and Recharts'
    ],
    skillsRequired: ['Python', 'Deep Learning Basics', 'REST APIs', 'Git'],
    tasks: [
      { week: 1, title: 'Data Ingestion & RAG Pipeline', detail: 'Set up news API pipelines and vectorize SEC 10-K filings into ChromaDB.' },
      { week: 2, title: 'Multi-Agent Framework Setup', detail: 'Configure LangGraph agent collaboration for analyst vs auditor roles.' },
      { week: 3, title: 'Model Fine-Tuning & Evaluation', detail: 'Evaluate output quality using RAGAS metric frameworks.' },
      { week: 4, title: 'Frontend Analytics Dashboard', detail: 'Develop dark-mode interactive charts with WebSocket streaming updates.' }
    ],
    mentor: {
      name: 'Dr. Aris Thorne',
      title: 'Principal AI Researcher',
      company: 'DotRepo Labs',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop'
    },
    faqs: [
      { question: 'Is prior experience with LangChain mandatory?', answer: 'Basic Python fluency is required; foundational agent concepts will be covered in initial orientation sessions.' },
      { question: 'What compute resources are provided?', answer: 'DotRepo provides cloud GPU credits (Nvidia T4/A10G) for the duration of the project.' }
    ],
    featured: true,
    createdAt: '2026-07-15'
  },
  {
    id: 'proj-2',
    name: 'Distributed Cloud Microservices Mesh & DevOps Pipeline',
    domain: 'DevOps',
    difficulty: 'Intermediate',
    duration: '1 Month',
    timeline: '4 Weeks',
    mode: 'Remote',
    teamSize: '2-3 Students',
    techStack: ['Docker', 'Kubernetes', 'Go', 'Prometheus', 'Grafana', 'GitHub Actions'],
    hasCertificate: true,
    isPortfolioProject: true,
    deadline: '2026-08-25',
    thumbnail: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?q=80&w=800&auto=format&fit=crop',
    overview: 'Construct an automated CI/CD microservices architecture with zero-downtime blue/green deployments and distributed tracing.',
    description: 'Learn how modern scale-ups manage thousands of microservices. You will construct Terraform templates, deploy Istio service meshes, setup Prometheus alerting rules, and build custom GitHub Actions workflows for automated code analysis and image vulnerability scanning.',
    learningOutcomes: [
      'Write IaC with Terraform for automated cloud provisioning',
      'Deploy production Kubernetes clusters with custom CRDs',
      'Set up full observability using Grafana, Jaeger tracing, and Loki logs',
      'Implement GitOps continuous delivery via ArgoCD'
    ],
    skillsRequired: ['Linux basics', 'Docker fundamentals', 'Shell scripting'],
    tasks: [
      { week: 1, title: 'Containerization & Local Compose', detail: 'Dockerize 3 Go microservices and set up local mesh.' },
      { week: 2, title: 'Kubernetes Cluster Setup', detail: 'Deploy to cloud K8s cluster with ingress controllers.' },
      { week: 3, title: 'CI/CD & GitOps Integration', detail: 'Automate build pipelines and zero-downtime deployments.' },
      { week: 4, title: 'Monitoring & Disaster Recovery', detail: 'Configure Prometheus metrics and chaos engineering scenarios.' }
    ],
    mentor: {
      name: 'Elena Rostova',
      title: 'Senior Site Reliability Engineer',
      company: 'ExaScale Cloud',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop'
    },
    faqs: [
      { question: 'Do we need a personal AWS/GCP account?', answer: 'No, all Cloud sandbox accounts with prepaid budgets are provided by DotRepo.' }
    ],
    featured: true,
    createdAt: '2026-07-18'
  },
  {
    id: 'proj-3',
    name: 'Full-Stack MERN E-Commerce Platform with Real-Time Analytics',
    domain: 'MERN',
    difficulty: 'Intermediate',
    duration: '1 Month',
    timeline: '4 Weeks',
    mode: 'Remote',
    teamSize: '2-4 Students',
    techStack: ['MongoDB', 'Express', 'React', 'Node.js', 'Redux Toolkit', 'Tailwind CSS'],
    hasCertificate: true,
    isPortfolioProject: true,
    deadline: '2026-08-28',
    thumbnail: 'https://images.unsplash.com/photo-1556742049-0a67dd35e478?q=80&w=800&auto=format&fit=crop',
    overview: 'Build a production-grade full-stack online shopping ecosystem with payment gateways, order tracking, and live inventory sockets.',
    description: 'Master the complete MERN stack by engineering a modern web app featuring secure JWT authentication, Stripe API integration, real-time stock updates via Socket.io, and a slick admin management dashboard with sales reporting.',
    learningOutcomes: [
      'Architect relational MongoDB schemas with aggregation pipelines',
      'Implement custom middleware, role-based access control (RBAC)',
      'Manage global React client state using Redux Toolkit & React Query',
      'Deploy MERN apps with automated serverless scaling'
    ],
    skillsRequired: ['JavaScript (ES6+)', 'Basic React', 'Node.js basics'],
    tasks: [
      { week: 1, title: 'REST API & Auth System', detail: 'Build JWT Auth, bcrypt password hashing, and user models.' },
      { week: 2, title: 'Product Catalog & Search Filters', detail: 'Develop high-performance fuzzy search and category filters.' },
      { week: 3, title: 'Checkout & Socket Inventory', detail: 'Integrate Webhooks and instant stock level notifications.' },
      { week: 4, title: 'Admin Panel & Performance Audit', detail: 'Build interactive sales analytics and optimize bundle size.' }
    ],
    mentor: {
      name: 'Marcus Vance',
      title: 'Lead Full-Stack Architect',
      company: 'DotRepo Core',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop'
    },
    faqs: [
      { question: 'Will my code be reviewed by senior devs?', answer: 'Yes, every task submission receives line-by-line feedback from core engineers.' }
    ],
    featured: true,
    createdAt: '2026-07-20'
  },
  {
    id: 'proj-4',
    name: 'Zero-Knowledge Cryptographic Authentication Engine',
    domain: 'Cyber Security',
    difficulty: 'Advanced',
    duration: '2 Months',
    timeline: '8 Weeks',
    mode: 'Remote',
    teamSize: '2 Students',
    techStack: ['Rust', 'WebAssembly', 'ZK-SNARKs', 'TypeScript', 'Node.js'],
    hasCertificate: true,
    isPortfolioProject: true,
    deadline: '2026-09-05',
    thumbnail: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?q=80&w=800&auto=format&fit=crop',
    overview: 'Design a privacy-first authentication module utilizing Zero-Knowledge proofs for passwordless identity verification.',
    description: 'Explore state-of-the-art cryptography. Build Circom circuits for ZK-SNARK proof generation, compile Rust proofs to WebAssembly for browser verification, and benchmark execution time against standard OAuth standards.',
    learningOutcomes: [
      'Write cryptographic arithmetic circuits with Circom and SnarkJS',
      'Compile high-performance Rust logic to WASM',
      'Implement resilient security auditing protocols',
      'Publish an open-source security npm package'
    ],
    skillsRequired: ['Data Structures', 'Basic Cryptography Concepts', 'TypeScript'],
    tasks: [
      { week: 1, title: 'Circuit Math Setup', detail: 'Write base Circom proof for preimage validation.' },
      { week: 2, title: 'Rust WASM Wrapper', detail: 'Implement browser verification layer in Rust.' },
      { week: 3, title: 'Full Auth Integration', detail: 'Integrate with Web Auth Server and JWT session tokens.' },
      { week: 4, title: 'Security Audit & Benchmark', detail: 'Conduct threat modeling and performance benchmark report.' }
    ],
    mentor: {
      name: 'Siddharth Rao',
      title: 'Cybersecurity & Crypto Lead',
      company: 'ShieldVault',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=200&auto=format&fit=crop'
    },
    faqs: [
      { question: 'Is this project suitable for research publication?', answer: 'Yes, top performers will co-author a research paper published on DotRepo Open Research.' }
    ],
    featured: false,
    createdAt: '2026-07-22'
  },
  {
    id: 'proj-5',
    name: 'Interactive Healthcare Mobile App for Patient Monitoring',
    domain: 'Android',
    difficulty: 'Intermediate',
    duration: '1 Month',
    timeline: '4 Weeks',
    mode: 'Remote',
    teamSize: '2-3 Students',
    techStack: ['Kotlin', 'Jetpack Compose', 'Android Jetpack', 'Firebase', 'Coroutines'],
    hasCertificate: true,
    isPortfolioProject: true,
    deadline: '2026-08-31',
    thumbnail: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=800&auto=format&fit=crop',
    overview: 'Develop a modern native Android application for real-time vital tracking, appointment scheduling, and offline telemetry sync.',
    description: 'Construct a fluid, modern Android app with Jetpack Compose, Room database offline caching, background worker syncs, and sleek dark mode UI compliant with Material 3 guidelines.',
    learningOutcomes: [
      'Master Jetpack Compose declarative UI architecture',
      'Handle background sync with WorkManager and Kotlin Coroutines',
      'Implement local Room caching with live Flow updates',
      'Integrate Bluetooth LE health device mock sensors'
    ],
    skillsRequired: ['Kotlin or Java basics', 'Object Oriented Programming'],
    tasks: [
      { week: 1, title: 'Compose UI Layouts', detail: 'Design responsive screen layouts and dark theme tokens.' },
      { week: 2, title: 'Room Database & Offline Flow', detail: 'Set up SQLite Room DAO pattern and state holders.' },
      { week: 3, title: 'BLE Sensor Telemetry Mock', detail: 'Simulate heart-rate Bluetooth stream data.' },
      { week: 4, title: 'APK Build & Testing', detail: 'Perform UI automated tests and release signed APK.' }
    ],
    mentor: {
      name: 'Aisha Patel',
      title: 'Senior Mobile Engineer',
      company: 'PulseHealth',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200&auto=format&fit=crop'
    },
    faqs: [
      { question: 'Do I need a physical Android device?', answer: 'No, Android Studio emulator works perfectly.' }
    ],
    featured: false,
    createdAt: '2026-07-25'
  },
  {
    id: 'proj-6',
    name: 'Enterprise Executive BI Dashboard with Power BI & Python',
    domain: 'Power BI',
    difficulty: 'Beginner',
    duration: '2 Weeks',
    timeline: '2 Weeks',
    mode: 'Remote',
    teamSize: '1-2 Students',
    techStack: ['Power BI', 'DAX', 'Python', 'Pandas', 'SQL Server'],
    hasCertificate: true,
    isPortfolioProject: true,
    deadline: '2026-08-20',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=800&auto=format&fit=crop',
    overview: 'Transform complex supply-chain datasets into interactive executive Power BI dashboards with automated KPI drill-downs.',
    description: 'Clean raw enterprise data with Python Pandas, model relational star schemas in Power BI, write complex DAX measure calculations, and generate actionable insights for executive leadership.',
    learningOutcomes: [
      'Write advanced DAX expressions for YoY comparison metrics',
      'Perform ETL pipeline transformations using Python Power Query scripts',
      'Design high-contrast minimal dark theme reports',
      'Publish interactive web embedded dashboards'
    ],
    skillsRequired: ['Excel basics', 'Analytical mindset', 'Basic SQL'],
    tasks: [
      { week: 1, title: 'ETL & Star Schema Modeling', detail: 'Clean dataset and create Fact vs Dimension tables.' },
      { week: 2, title: 'DAX Measures & Interactive Visuals', detail: 'Build interactive filter slicers, KPIs, and tooltips.' }
    ],
    mentor: {
      name: 'Vikram Mehta',
      title: 'Lead Data Analytics Consultant',
      company: 'DotRepo Insights',
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=200&auto=format&fit=crop'
    },
    faqs: [
      { question: 'Is Power BI Desktop free to use?', answer: 'Yes, Power BI Desktop is completely free on Windows.' }
    ],
    featured: false,
    createdAt: '2026-07-26'
  }
];

export const INITIAL_INTERNSHIPS: Internship[] = [
  {
    id: 'intern-1',
    company: 'DotRepo',
    role: 'Frontend Engineering Intern',
    domain: 'React',
    duration: '3 Months',
    mode: 'Remote',
    openings: 8,
    stipend: '$800 - $1,200 / month',
    requirements: [
      'Proficiency in React 18+, TypeScript, and Tailwind CSS',
      'Understanding of component optimization and state management',
      'Familiarity with Framer Motion animations and responsive design',
      'Git workflow proficiency (PRs, code reviews, feature branching)'
    ],
    responsibilities: [
      'Build sleek, pixel-perfect user interfaces for core DotRepo products',
      'Collaborate directly with product managers and UI designers',
      'Optimize web performance to maintain 95+ Lighthouse scores',
      'Implement reusable UI design system components'
    ],
    techStack: ['React', 'TypeScript', 'Tailwind CSS', 'Framer Motion', 'Vite'],
    hasCertificate: true,
    hasLOR: true,
    performanceReview: 'Weekly 1-on-1 mentor syncs, bi-weekly code quality audits, and mid-term performance review.',
    selectionProcess: [
      { step: 1, title: 'Application Screening', description: 'Review of resume, GitHub projects, and portfolio quality.' },
      { step: 2, title: 'Technical Design Challenge', description: 'Take-home 48-hour interactive UI component challenge.' },
      { step: 3, title: 'Technical & Culture Interview', description: '45-minute live pair coding with Senior Frontend Engineer.' },
      { step: 4, title: 'Official Offer Letter', description: 'Onboarding roadmap, stipend confirmation, and team assignment.' }
    ],
    deadline: '2026-08-30',
    thumbnail: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?q=80&w=800&auto=format&fit=crop',
    overview: 'Join DotRepo’s core UI engineering group to build next-generation web products used by thousands of global developers.',
    featured: true,
    createdAt: '2026-07-10'
  },
  {
    id: 'intern-2',
    company: 'DotRepo',
    role: 'AI & Machine Learning Research Intern',
    domain: 'Artificial Intelligence',
    duration: '3 Months',
    mode: 'Remote',
    openings: 5,
    stipend: '$1,000 - $1,500 / month',
    requirements: [
      'Strong mathematical foundation in linear algebra, calculus, and probability',
      'Experience with Python, PyTorch, and Transformers library',
      'Understanding of LLM fine-tuning techniques (LoRA, QLoRA)',
      'Demonstrated interest via GitHub projects or Kaggle competitions'
    ],
    responsibilities: [
      'Benchmark and evaluate open-weights foundation models for code generation',
      'Implement custom RAG pipelines and vector search indexing',
      'Co-author research technical blogs and open-source models',
      'Deploy low-latency inference services with Triton or vLLM'
    ],
    techStack: ['Python', 'PyTorch', 'Hugging Face', 'FastAPI', 'Milvus', 'CUDA'],
    hasCertificate: true,
    hasLOR: true,
    performanceReview: 'Bi-weekly benchmark progress reports, code review scores, and final research presentation.',
    selectionProcess: [
      { step: 1, title: 'Profile Evaluation', description: 'Evaluation of Kaggle profile, GitHub code, and coursework.' },
      { step: 2, title: 'ML Problem Solving Assessment', description: 'Take-home notebook analysis and data modeling.' },
      { step: 3, title: 'AI Engineering Interview', description: 'Live discussion on model architecture and fine-tuning.' },
      { step: 4, title: 'Internship Onboarding', description: 'Allocation of dedicated GPU instances and project assignment.' }
    ],
    deadline: '2026-09-01',
    thumbnail: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=800&auto=format&fit=crop',
    overview: 'Work on cutting-edge LLM agentic systems and high-performance inference pipelines alongside PhD research mentors.',
    featured: true,
    createdAt: '2026-07-12'
  },
  {
    id: 'intern-3',
    company: 'DotRepo',
    role: 'Backend Systems & Cloud Intern',
    domain: 'Backend',
    duration: '2 Months',
    mode: 'Remote',
    openings: 6,
    stipend: '$750 - $1,100 / month',
    requirements: [
      'Solid command over Node.js, Express, Go, or Python FastAPI',
      'Experience designing RESTful APIs and PostgreSQL/MongoDB databases',
      'Knowledge of caching with Redis and message queues like RabbitMQ/Kafka',
      'Understanding of Docker containerization basics'
    ],
    responsibilities: [
      'Develop scalable, high-throughput backend microservices',
      'Optimize database queries and schema indexes for zero latency',
      'Write comprehensive integration unit tests (Jest / PyTest)',
      'Monitor application metrics and error telemetry'
    ],
    techStack: ['Node.js', 'Express', 'PostgreSQL', 'Redis', 'Docker', 'AWS'],
    hasCertificate: true,
    hasLOR: true,
    performanceReview: 'Weekly sprint demos, load test review metrics, and mentor feedback.',
    selectionProcess: [
      { step: 1, title: 'Application Review', description: 'Verification of past projects and backend coursework.' },
      { step: 2, title: 'Backend Coding Test', description: 'Build an API endpoint with rate limiting and database schema.' },
      { step: 3, title: 'System Architecture Interview', description: 'Discussion on API security, indexing, and scaling.' },
      { step: 4, title: 'Offer Confirmation', description: 'Formal letter and access to development server cluster.' }
    ],
    deadline: '2026-08-28',
    thumbnail: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=800&auto=format&fit=crop',
    overview: 'Build robust server architectures handling high concurrent web traffic with 99.9% uptime SLA.',
    featured: true,
    createdAt: '2026-07-14'
  },
  {
    id: 'intern-4',
    company: 'DotRepo',
    role: 'UI/UX Product Design Intern',
    domain: 'UI UX',
    duration: '2 Months',
    mode: 'Remote',
    openings: 4,
    stipend: '$700 - $1,000 / month',
    requirements: [
      'Strong portfolio demonstrating sleek Figma design systems and UI prototypes',
      'Obsession with typography, spacing, micro-interactions, and dark mode aesthetics',
      'Understanding of UX research, wireframing, and usability testing',
      'Basic knowledge of HTML/CSS capabilities'
    ],
    responsibilities: [
      'Design high-fidelity component libraries and interactive Figma flows',
      'Conduct user interviews to refine product navigation and UX friction',
      'Collaborate with frontend developers to ensure design system fidelity',
      'Create visual marketing assets and product showcase mockups'
    ],
    techStack: ['Figma', 'Framer', 'Protopie', 'Design Systems', 'User Research'],
    hasCertificate: true,
    hasLOR: true,
    performanceReview: 'Weekly design critique sessions, prototype usability scores, and mentor reviews.',
    selectionProcess: [
      { step: 1, title: 'Portfolio Review', description: 'Evaluation of Figma design files and UX case studies.' },
      { step: 2, title: 'Design Sprint Challenge', description: '24-hour design exercise creating a dark-mode SaaS dashboard component.' },
      { step: 3, title: 'Design Discussion', description: 'Walkthrough of design decisions with Lead Product Designer.' },
      { step: 4, title: 'Welcome to DotRepo', description: 'Onboarding into DotRepo Figma organization.' }
    ],
    deadline: '2026-08-25',
    thumbnail: 'https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?q=80&w=800&auto=format&fit=crop',
    overview: 'Craft world-class dark mode digital experiences inspired by Apple, Vercel, and Linear design principles.',
    featured: false,
    createdAt: '2026-07-16'
  }
];

export const INITIAL_CERTIFICATES: Certificate[] = [
  {
    id: 'cert-101',
    certificateNumber: 'DR-CERT-2026-9812',
    title: 'Autonomous Multi-Agent AI System Project',
    type: 'Project',
    issuedTo: 'Alex Mercer',
    domain: 'Artificial Intelligence',
    issueDate: '2026-06-15',
    verificationUrl: 'https://dotrepo.org/verify/DR-CERT-2026-9812',
    skills: ['Python', 'PyTorch', 'LangChain', 'FastAPI', 'RAG']
  },
  {
    id: 'cert-102',
    certificateNumber: 'DR-LOR-2026-4409',
    title: 'Frontend Engineering Internship Excellence',
    type: 'Internship',
    issuedTo: 'Alex Mercer',
    domain: 'React',
    issueDate: '2026-05-30',
    verificationUrl: 'https://dotrepo.org/verify/DR-LOR-2026-4409',
    skills: ['React 19', 'TypeScript', 'Framer Motion', 'Tailwind CSS', 'Performance Optimization']
  }
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    id: 'team-1',
    name: 'Karan Sharma',
    role: 'Founder & CEO',
    bio: 'Ex-Google AI Engineer. Passionate about empowering students through hands-on product creation.',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop',
    linkedin: 'https://linkedin.com',
    github: 'https://github.com'
  },
  {
    id: 'team-2',
    name: 'Sophia Chen',
    role: 'Co-Founder & CTO',
    bio: 'Former Tech Lead at Stripe. Specialist in high-performance distributed systems and AI platforms.',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=300&auto=format&fit=crop',
    linkedin: 'https://linkedin.com',
    github: 'https://github.com'
  },
  {
    id: 'team-3',
    name: 'David Miller',
    role: 'Head of Product & Design',
    bio: 'Veteran UI/UX designer with 10+ years shaping top-tier minimalist SaaS applications.',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop',
    linkedin: 'https://linkedin.com'
  },
  {
    id: 'team-4',
    name: 'Ananya Roy',
    role: 'Lead AI Mentor',
    bio: 'PhD candidate in Machine Learning. Guiding students in agentic workflows and computer vision.',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300&auto=format&fit=crop',
    linkedin: 'https://linkedin.com',
    github: 'https://github.com'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Rohan Deshmukh',
    role: 'Full Stack Engineer',
    college: 'IIT Bombay',
    content: 'Building the Autonomous AI Agent project at DotRepo was the turning point of my career. The code reviews were as rigorous as FAANG companies, and I cracked my dream job at Microsoft within 2 months of completion!',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop',
    companyPlacements: 'Placed at Microsoft'
  },
  {
    id: 'test-2',
    name: 'Priya Sundaram',
    role: 'Frontend Developer',
    college: 'BITS Pilani',
    content: 'DotRepo provided me real industry experience, not just theoretical tutorials. The Letter of Recommendation and verified certificate gave my portfolio immense credibility during interviews.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop',
    companyPlacements: 'Placed at Stripe'
  },
  {
    id: 'test-3',
    name: 'Ankit Verma',
    role: 'DevOps & Cloud Specialist',
    college: 'NIT Trichy',
    content: 'The mentor guidance on Kubernetes and Prometheus pipelines was exceptional. DotRepo’s dark-mode minimal interface and seamless application tracking made the entire journey effortless.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=150&auto=format&fit=crop',
    companyPlacements: 'Placed at AWS'
  }
];

export const FAQ_ITEMS: FAQItem[] = [
  {
    id: 'faq-1',
    category: 'General',
    question: 'What is DotRepo and who is it for?',
    answer: 'DotRepo is a premium talent accelerator and product studio where students and early-career developers build real-world software products, work on industry-grade projects, and join remote internships mentored by senior tech leaders.'
  },
  {
    id: 'faq-2',
    category: 'Projects',
    question: 'Are the projects self-paced or live-monitored?',
    answer: 'Projects follow structured weekly milestones with live mentor syncs, dedicated Slack/Discord channels, and mandatory code pull-request audits.'
  },
  {
    id: 'faq-3',
    category: 'Certificates',
    question: 'Are DotRepo certificates cryptographically verified?',
    answer: 'Yes! Every certificate and Letter of Recommendation (LOR) issued by DotRepo comes with a unique verification ID and instant online validation portal.'
  },
  {
    id: 'faq-4',
    category: 'Internships',
    question: 'Do DotRepo internships offer stipends?',
    answer: 'Yes, all core DotRepo internships are performance-rewarded and stipend-backed, ranging from $700 to $1,500/month based on role and impact.'
  },
  {
    id: 'faq-5',
    category: 'Applications',
    question: 'How long does the application review process take?',
    answer: 'Our admissions team evaluates submissions within 48 to 72 business hours. You can track your application status live in your Profile Dashboard.'
  }
];

export const COMPANY_LOGOS = [
  { name: 'Vercel', logo: '▲ Vercel' },
  { name: 'Stripe', logo: 'S Stripe' },
  { name: 'Linear', logo: '◈ Linear' },
  { name: 'Notion', logo: 'N Notion' },
  { name: 'GitHub', logo: '⚡ GitHub' },
  { name: 'OpenAI', logo: '✳ OpenAI' },
  { name: 'AWS', logo: '☁ AWS' },
  { name: 'Cloudflare', logo: '⟁ Cloudflare' }
];

export const STATS_DATA = [
  { label: 'Active Projects', value: 48, suffix: '+' },
  { label: 'Internships', value: 120, suffix: '+' },
  { label: 'Students Impacted', value: 3500, suffix: '+' },
  { label: 'Domains Covered', value: 18, suffix: '+' },
  { label: 'Certificates Issued', value: 2800, suffix: '+' }
];
