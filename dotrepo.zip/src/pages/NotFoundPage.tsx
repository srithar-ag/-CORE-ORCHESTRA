import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, FileQuestion } from 'lucide-react';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="max-w-md mx-auto px-4 py-24 text-center space-y-6">
      <div className="w-16 h-16 rounded-2xl bg-[#111111] border border-[#2A2A2A] text-white flex items-center justify-center mx-auto">
        <FileQuestion className="w-8 h-8 text-[#A0A0A0]" />
      </div>

      <div className="space-y-2">
        <span className="text-4xl font-mono font-extrabold text-white">404</span>
        <h1 className="text-xl font-bold text-white">Page Not Found</h1>
        <p className="text-xs text-[#A0A0A0]">
          The route or page you are looking for does not exist or may have been moved.
        </p>
      </div>

      <Link
        to="/"
        className="inline-flex items-center gap-2 px-6 py-2.5 bg-white text-black font-bold rounded-xl text-xs hover:bg-neutral-200 transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" /> Back to Home
      </Link>
    </div>
  );
};
