import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, FolderGit2, X, RotateCcw } from 'lucide-react';
import { Project, Domain, Difficulty, Duration } from '../types';
import { ProjectCard } from '../components/ProjectCard';

interface ProjectsPageProps {
  onApplyProject: (project: Project) => void;
}

const DOMAINS: Domain[] = [
  'All',
  'Artificial Intelligence',
  'Machine Learning',
  'Python',
  'Java',
  'JavaScript',
  'React',
  'Node.js',
  'MERN',
  'Frontend',
  'Backend',
  'Cloud',
  'Cyber Security',
  'UI UX',
  'Data Science',
  'Power BI',
  'DevOps',
  'Blockchain',
  'IoT',
  'Android',
  'Open Source'
];

export const ProjectsPage: React.FC<ProjectsPageProps> = ({ onApplyProject }) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialDomain = (searchParams.get('domain') as Domain) || 'All';

  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<Domain>(initialDomain);
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [selectedDuration, setSelectedDuration] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'newest' | 'difficulty'>('newest');

  useEffect(() => {
    fetchProjects();
  }, [selectedDomain, selectedDifficulty, selectedDuration, searchQuery]);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const queryParts = [];
      if (selectedDomain && selectedDomain !== 'All') queryParts.push(`domain=${encodeURIComponent(selectedDomain)}`);
      if (selectedDifficulty && selectedDifficulty !== 'All') queryParts.push(`difficulty=${encodeURIComponent(selectedDifficulty)}`);
      if (selectedDuration && selectedDuration !== 'All') queryParts.push(`duration=${encodeURIComponent(selectedDuration)}`);
      if (searchQuery) queryParts.push(`search=${encodeURIComponent(searchQuery)}`);

      const queryString = queryParts.length ? `?${queryParts.join('&')}` : '';
      const res = await fetch(`/api/projects${queryString}`);
      const data = await res.json();

      let result = Array.isArray(data) ? data : [];
      if (sortBy === 'difficulty') {
        const orderMap: Record<string, number> = { Beginner: 1, Intermediate: 2, Advanced: 3 };
        result.sort((a, b) => (orderMap[b.difficulty] || 0) - (orderMap[a.difficulty] || 0));
      }

      setProjects(result);
    } catch (err) {
      console.error('Error fetching projects:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedDomain('All');
    setSelectedDifficulty('All');
    setSelectedDuration('All');
    setSearchParams({});
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Page Header */}
      <div className="space-y-2">
        <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0] flex items-center gap-1.5">
          <FolderGit2 className="w-4 h-4 text-white" /> Industry Software Cohorts
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">Explore Real-World Projects</h1>
        <p className="text-xs sm:text-sm text-[#A0A0A0] max-w-2xl">
          Build production-grade systems mentored by senior engineers. Select your preferred technology stack and difficulty level.
        </p>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-4 sm:p-5 space-y-4 shadow-xl">
        
        {/* Top Input & Sort Bar */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#A0A0A0]" />
            <input
              type="text"
              placeholder="Search by project name, tech stack (e.g., PyTorch, React, Docker)..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-[#161616] border border-[#2A2A2A] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-[#666666] focus:outline-none focus:border-white transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A0A0A0] hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Difficulty Dropdown */}
          <select
            value={selectedDifficulty}
            onChange={e => setSelectedDifficulty(e.target.value)}
            className="w-full sm:w-auto bg-[#161616] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-white"
          >
            <option value="All">All Difficulties</option>
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Advanced">Advanced</option>
          </select>

          {/* Duration Dropdown */}
          <select
            value={selectedDuration}
            onChange={e => setSelectedDuration(e.target.value)}
            className="w-full sm:w-auto bg-[#161616] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-white"
          >
            <option value="All">All Durations</option>
            <option value="1 Week">1 Week</option>
            <option value="2 Weeks">2 Weeks</option>
            <option value="1 Month">1 Month</option>
            <option value="2 Months">2 Months</option>
            <option value="3 Months">3 Months</option>
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as any)}
            className="w-full sm:w-auto bg-[#161616] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-white"
          >
            <option value="newest">Sort: Newest First</option>
            <option value="difficulty">Sort: Highest Difficulty</option>
          </select>
        </div>

        {/* Domain Filter Pills Scroll */}
        <div className="pt-2 border-t border-[#2A2A2A]/60 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-[11px] font-semibold text-[#666666] uppercase tracking-wider shrink-0 pr-2">
            Domain:
          </span>
          {DOMAINS.map(domain => {
            const active = selectedDomain === domain;
            return (
              <button
                key={domain}
                onClick={() => {
                  setSelectedDomain(domain);
                  setSearchParams(domain === 'All' ? {} : { domain });
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium shrink-0 border transition-all duration-200 ${
                  active
                    ? 'bg-white text-black border-white font-bold'
                    : 'bg-[#161616] text-[#A0A0A0] border-[#2A2A2A] hover:text-white hover:border-[#444]'
                }`}
              >
                {domain}
              </button>
            );
          })}
        </div>

      </div>

      {/* Active Filter Badges */}
      {(selectedDomain !== 'All' || selectedDifficulty !== 'All' || selectedDuration !== 'All' || searchQuery) && (
        <div className="flex items-center gap-3 text-xs text-[#A0A0A0]">
          <span>Active Filters:</span>
          {selectedDomain !== 'All' && (
            <span className="bg-[#161616] border border-[#2A2A2A] px-2.5 py-1 rounded-full text-white">
              Domain: {selectedDomain}
            </span>
          )}
          {selectedDifficulty !== 'All' && (
            <span className="bg-[#161616] border border-[#2A2A2A] px-2.5 py-1 rounded-full text-white">
              Difficulty: {selectedDifficulty}
            </span>
          )}
          {selectedDuration !== 'All' && (
            <span className="bg-[#161616] border border-[#2A2A2A] px-2.5 py-1 rounded-full text-white">
              Duration: {selectedDuration}
            </span>
          )}
          <button
            onClick={handleResetFilters}
            className="text-xs text-rose-400 hover:underline flex items-center gap-1 ml-auto"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset All Filters
          </button>
        </div>
      )}

      {/* Projects Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="h-96 bg-[#161616] rounded-2xl animate-pulse border border-[#2A2A2A]" />
          ))}
        </div>
      ) : projects.length === 0 ? (
        <div className="text-center py-20 bg-[#111111] border border-[#2A2A2A] rounded-2xl space-y-3">
          <FolderGit2 className="w-12 h-12 text-[#444] mx-auto" />
          <h3 className="text-base font-bold text-white">No Projects Found</h3>
          <p className="text-xs text-[#A0A0A0]">Try adjusting your search query or domain filters.</p>
          <button
            onClick={handleResetFilters}
            className="px-4 py-2 bg-white text-black font-semibold rounded-lg text-xs hover:bg-neutral-200 transition-colors inline-block mt-2"
          >
            Clear Search
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map(project => (
            <ProjectCard key={project.id} project={project} onApply={onApplyProject} />
          ))}
        </div>
      )}

    </div>
  );
};
