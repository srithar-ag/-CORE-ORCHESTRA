import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Project, Internship, Application, ApplicationStatus } from '../types';
import {
  Shield,
  FolderGit2,
  Briefcase,
  Users,
  Plus,
  Trash2,
  Edit2,
  Calendar,
  CheckCircle2,
  XCircle,
  FileText,
  Clock,
  ChevronRight,
  TrendingUp,
  Download
} from 'lucide-react';

export const AdminPage: React.FC = () => {
  const { isAdmin } = useAuth();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'applications' | 'projects' | 'internships' | 'analytics'>('applications');
  
  const [projects, setProjects] = useState<Project[]>([]);
  const [internships, setInternships] = useState<Internship[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal / Form States
  const [showCreateProjectModal, setShowCreateProjectModal] = useState(false);
  const [showCreateInternModal, setShowCreateInternModal] = useState(false);
  const [selectedAppForSchedule, setSelectedAppForSchedule] = useState<Application | null>(null);

  // Schedule Interview Form State
  const [interviewForm, setInterviewForm] = useState({
    date: '2026-08-15',
    time: '11:00 AM PST',
    link: 'https://meet.dotrepo.org/int-demo',
    notes: 'System architecture review and live pair coding.'
  });

  // Create Project Form State
  const [newProject, setNewProject] = useState({
    name: '',
    domain: 'Artificial Intelligence',
    difficulty: 'Intermediate',
    duration: '1 Month',
    timeline: '4 Weeks',
    mode: 'Remote',
    teamSize: '2-3 Students',
    techStack: 'Python, React, FastAPI',
    overview: '',
    description: '',
    deadline: '2026-08-30'
  });

  // Create Internship Form State
  const [newIntern, setNewIntern] = useState({
    company: 'DotRepo',
    role: '',
    domain: 'React',
    duration: '3 Months',
    mode: 'Remote',
    openings: 5,
    stipend: '$800 / month',
    overview: '',
    deadline: '2026-08-30',
    techStack: 'React, TypeScript, Tailwind CSS'
  });

  useEffect(() => {
    fetchAllAdminData();
  }, []);

  const fetchAllAdminData = async () => {
    setLoading(true);
    try {
      const [projRes, internRes, appRes] = await Promise.all([
        fetch('/api/projects'),
        fetch('/api/internships'),
        fetch('/api/applications')
      ]);
      const [pData, iData, aData] = await Promise.all([
        projRes.json(),
        internRes.json(),
        appRes.json()
      ]);
      setProjects(Array.isArray(pData) ? pData : []);
      setInternships(Array.isArray(iData) ? iData : []);
      setApplications(Array.isArray(aData) ? aData : []);
    } catch (err) {
      console.error('Error loading admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateAppStatus = async (appId: string, status: ApplicationStatus, interviewDetails?: any) => {
    try {
      const res = await fetch(`/api/applications/${appId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, interviewDetails })
      });
      const data = await res.json();
      if (data.success) {
        showToast('Status Updated', `Application moved to ${status}`, 'success');
        setApplications(prev => prev.map(a => (a.id === appId ? data.application : a)));
        setSelectedAppForSchedule(null);
      }
    } catch (err) {
      showToast('Update Failed', 'Server error updating status.', 'error');
    }
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProject.name) {
      showToast('Project Name Required', '', 'error');
      return;
    }

    try {
      const payload = {
        ...newProject,
        techStack: newProject.techStack.split(',').map(s => s.trim()),
        hasCertificate: true,
        isPortfolioProject: true,
        thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=800&auto=format&fit=crop',
        learningOutcomes: ['Production engineering fundamentals', 'System architecture optimization'],
        skillsRequired: ['Git', 'Data Structures'],
        tasks: [{ week: 1, title: 'Architecture Setup', detail: 'Build base API routes' }],
        mentor: {
          name: 'Karan Sharma',
          title: 'Founder & CEO',
          company: 'DotRepo',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop'
        },
        faqs: []
      };

      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      setProjects([data, ...projects]);
      setShowCreateProjectModal(false);
      showToast('Project Created!', 'New project cohort added to live directory.', 'success');
    } catch (err) {
      showToast('Creation Failed', '', 'error');
    }
  };

  const handleDeleteProject = async (projId: string) => {
    if (!confirm('Are you sure you want to delete this project?')) return;
    try {
      await fetch(`/api/projects/${projId}`, { method: 'DELETE' });
      setProjects(prev => prev.filter(p => p.id !== projId));
      showToast('Project Deleted', '', 'info');
    } catch (err) {
      showToast('Delete Failed', '', 'error');
    }
  };

  const handleCreateInternship = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIntern.role) {
      showToast('Role Title Required', '', 'error');
      return;
    }

    try {
      const payload = {
        ...newIntern,
        techStack: newIntern.techStack.split(',').map(s => s.trim()),
        hasCertificate: true,
        hasLOR: true,
        requirements: ['Strong problem-solving ability', 'Proficiency in tech stack'],
        responsibilities: ['Build scalable feature modules', 'Perform code reviews'],
        performanceReview: 'Bi-weekly mentor feedback sessions.',
        selectionProcess: [
          { step: 1, title: 'Screening', description: 'Resume review' },
          { step: 2, title: 'Offer', description: 'Confirmation' }
        ],
        thumbnail: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?q=80&w=800&auto=format&fit=crop'
      };

      const res = await fetch('/api/internships', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      setInternships([data, ...internships]);
      setShowCreateInternModal(false);
      showToast('Internship Created!', 'New role opening added to live directory.', 'success');
    } catch (err) {
      showToast('Creation Failed', '', 'error');
    }
  };

  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <Shield className="w-12 h-12 text-[#666] mx-auto" />
        <h2 className="text-2xl font-bold text-white">Admin Authentication Required</h2>
        <p className="text-xs text-[#A0A0A0]">Please sign in as Admin command to access the administration panel.</p>
        <a href="/login" className="inline-block px-6 py-2.5 bg-white text-black font-bold text-xs rounded-xl hover:bg-neutral-200">
          Sign In as Admin
        </a>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono text-emerald-400 font-semibold flex items-center gap-1.5">
            <Shield className="w-4 h-4" /> DotRepo Core Admin Command
          </span>
          <h1 className="text-3xl font-extrabold text-white mt-0.5">Admin Management Dashboard</h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowCreateProjectModal(true)}
            className="px-4 py-2 bg-white text-black font-bold rounded-xl text-xs hover:bg-neutral-200 transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" /> New Project
          </button>
          <button
            onClick={() => setShowCreateInternModal(true)}
            className="px-4 py-2 bg-[#161616] hover:bg-[#222222] border border-[#2A2A2A] text-white font-semibold rounded-xl text-xs flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" /> New Internship
          </button>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-5 space-y-1">
          <span className="text-[11px] text-[#A0A0A0] uppercase font-semibold">Total Applications</span>
          <span className="text-3xl font-extrabold text-white block font-mono">{applications.length}</span>
        </div>
        <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-5 space-y-1">
          <span className="text-[11px] text-[#A0A0A0] uppercase font-semibold">Active Projects</span>
          <span className="text-3xl font-extrabold text-white block font-mono">{projects.length}</span>
        </div>
        <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-5 space-y-1">
          <span className="text-[11px] text-[#A0A0A0] uppercase font-semibold">Open Internships</span>
          <span className="text-3xl font-extrabold text-white block font-mono">{internships.length}</span>
        </div>
        <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-5 space-y-1">
          <span className="text-[11px] text-[#A0A0A0] uppercase font-semibold">Shortlisted Rate</span>
          <span className="text-3xl font-extrabold text-emerald-400 block font-mono">
            {applications.length > 0
              ? `${Math.round((applications.filter(a => a.status !== 'Applied').length / applications.length) * 100)}%`
              : '0%'}
          </span>
        </div>
      </div>

      {/* Admin Nav Tabs */}
      <div className="flex items-center gap-2 border-b border-[#2A2A2A] pb-2">
        <button
          onClick={() => setActiveTab('applications')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl transition-colors ${
            activeTab === 'applications' ? 'bg-white text-black font-bold' : 'text-[#A0A0A0] hover:text-white'
          }`}
        >
          Manage Applications ({applications.length})
        </button>
        <button
          onClick={() => setActiveTab('projects')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl transition-colors ${
            activeTab === 'projects' ? 'bg-white text-black font-bold' : 'text-[#A0A0A0] hover:text-white'
          }`}
        >
          Manage Projects ({projects.length})
        </button>
        <button
          onClick={() => setActiveTab('internships')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl transition-colors ${
            activeTab === 'internships' ? 'bg-white text-black font-bold' : 'text-[#A0A0A0] hover:text-white'
          }`}
        >
          Manage Internships ({internships.length})
        </button>
      </div>

      {/* TAB 1: APPLICATIONS LIST & MANAGEMENT */}
      {activeTab === 'applications' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Candidate Submissions</h3>
          
          <div className="space-y-4">
            {applications.map(app => (
              <div key={app.id} className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#2A2A2A] pb-3">
                  <div>
                    <span className="text-[10px] font-mono text-[#A0A0A0]">Ref: {app.referenceId}</span>
                    <h4 className="text-base font-bold text-white">{app.fullName}</h4>
                    <p className="text-xs text-[#A0A0A0]">{app.email} • {app.college} ({app.degree})</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-xs font-mono border bg-[#111111] text-white border-[#2A2A2A]">
                      {app.status}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-[#A0A0A0]">
                  <div>
                    <span className="text-white font-semibold block">Applying For:</span>
                    <span>{app.itemTitle} ({app.itemType})</span>
                  </div>
                  <div>
                    <span className="text-white font-semibold block">Skills & Tech:</span>
                    <span>{app.programmingLanguages?.join(', ')} • {app.frameworks?.join(', ')}</span>
                  </div>
                  <div className="sm:col-span-2">
                    <span className="text-white font-semibold block">Why Join DotRepo:</span>
                    <p className="italic bg-[#111111] p-3 rounded-xl border border-[#2A2A2A] mt-1">"{app.whyJoin}"</p>
                  </div>
                </div>

                {/* Admin Action Buttons */}
                <div className="pt-2 flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => handleUpdateAppStatus(app.id, 'Shortlisted')}
                    className="px-3 py-1.5 bg-[#111111] hover:bg-purple-900/40 border border-[#2A2A2A] text-purple-300 text-xs font-semibold rounded-lg"
                  >
                    Shortlist
                  </button>
                  <button
                    onClick={() => setSelectedAppForSchedule(app)}
                    className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold rounded-lg flex items-center gap-1"
                  >
                    <Calendar className="w-3.5 h-3.5" /> Schedule Interview
                  </button>
                  <button
                    onClick={() => handleUpdateAppStatus(app.id, 'Accepted')}
                    className="px-3 py-1.5 bg-white text-black text-xs font-bold rounded-lg"
                  >
                    Accept Student
                  </button>
                  <button
                    onClick={() => handleUpdateAppStatus(app.id, 'Rejected')}
                    className="px-3 py-1.5 bg-[#111111] hover:bg-rose-900/40 border border-[#2A2A2A] text-rose-400 text-xs rounded-lg"
                  >
                    Reject
                  </button>
                  {app.githubUrl && (
                    <a
                      href={app.githubUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 bg-[#111111] border border-[#2A2A2A] text-[#A0A0A0] hover:text-white text-xs rounded-lg ml-auto"
                    >
                      GitHub Profile
                    </a>
                  )}
                </div>

              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: PROJECTS MANAGEMENT */}
      {activeTab === 'projects' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Project Directory</h3>
            <button
              onClick={() => setShowCreateProjectModal(true)}
              className="px-3 py-1.5 bg-white text-black text-xs font-bold rounded-lg"
            >
              + Add Project
            </button>
          </div>

          <div className="space-y-3">
            {projects.map(proj => (
              <div key={proj.id} className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">{proj.name}</h4>
                  <span className="text-xs text-[#A0A0A0]">{proj.domain} • {proj.difficulty} • {proj.duration}</span>
                </div>
                <button
                  onClick={() => handleDeleteProject(proj.id)}
                  className="p-2 text-rose-400 hover:bg-rose-950/40 rounded-lg"
                  title="Delete Project"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: INTERNSHIPS MANAGEMENT */}
      {activeTab === 'internships' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Internships Directory</h3>
            <button
              onClick={() => setShowCreateInternModal(true)}
              className="px-3 py-1.5 bg-white text-black text-xs font-bold rounded-lg"
            >
              + Add Internship
            </button>
          </div>

          <div className="space-y-3">
            {internships.map(intern => (
              <div key={intern.id} className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">{intern.role}</h4>
                  <span className="text-xs text-[#A0A0A0]">{intern.company} • {intern.stipend} • {intern.duration}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Schedule Interview Modal */}
      {selectedAppForSchedule && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-md bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 text-white space-y-4">
            <h3 className="text-base font-bold text-white">Schedule Interview</h3>
            <p className="text-xs text-[#A0A0A0]">Candidate: {selectedAppForSchedule.fullName} ({selectedAppForSchedule.email})</p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[#A0A0A0] mb-1">Interview Date</label>
                <input
                  type="date"
                  value={interviewForm.date}
                  onChange={e => setInterviewForm({ ...interviewForm, date: e.target.value })}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                />
              </div>
              <div>
                <label className="block text-[#A0A0A0] mb-1">Interview Time</label>
                <input
                  type="text"
                  value={interviewForm.time}
                  onChange={e => setInterviewForm({ ...interviewForm, time: e.target.value })}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                />
              </div>
              <div>
                <label className="block text-[#A0A0A0] mb-1">Meeting Link</label>
                <input
                  type="url"
                  value={interviewForm.link}
                  onChange={e => setInterviewForm({ ...interviewForm, link: e.target.value })}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                />
              </div>
              <div>
                <label className="block text-[#A0A0A0] mb-1">Notes for Candidate</label>
                <textarea
                  rows={2}
                  value={interviewForm.notes}
                  onChange={e => setInterviewForm({ ...interviewForm, notes: e.target.value })}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white resize-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedAppForSchedule(null)}
                className="px-4 py-2 bg-[#111111] text-[#A0A0A0] rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                onClick={() => handleUpdateAppStatus(selectedAppForSchedule.id, 'Scheduled Interview', interviewForm)}
                className="px-5 py-2 bg-emerald-500 text-black font-bold rounded-xl text-xs"
              >
                Confirm & Notify
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Project Modal */}
      {showCreateProjectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <form onSubmit={handleCreateProject} className="w-full max-w-lg bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 text-white space-y-4 max-h-[85vh] overflow-y-auto">
            <h3 className="text-base font-bold text-white">Create New Project Cohort</h3>
            
            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[#A0A0A0] mb-1">Project Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Distributed Database Storage Engine"
                  value={newProject.name}
                  onChange={e => setNewProject({ ...newProject, name: e.target.value })}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#A0A0A0] mb-1">Domain</label>
                  <input
                    type="text"
                    value={newProject.domain}
                    onChange={e => setNewProject({ ...newProject, domain: e.target.value as any })}
                    className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                  />
                </div>
                <div>
                  <label className="block text-[#A0A0A0] mb-1">Difficulty</label>
                  <select
                    value={newProject.difficulty}
                    onChange={e => setNewProject({ ...newProject, difficulty: e.target.value as any })}
                    className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-[#A0A0A0] mb-1">Tech Stack (comma separated)</label>
                <input
                  type="text"
                  value={newProject.techStack}
                  onChange={e => setNewProject({ ...newProject, techStack: e.target.value })}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                />
              </div>
              <div>
                <label className="block text-[#A0A0A0] mb-1">Overview</label>
                <textarea
                  rows={2}
                  value={newProject.overview}
                  onChange={e => setNewProject({ ...newProject, overview: e.target.value })}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white resize-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCreateProjectModal(false)}
                className="px-4 py-2 bg-[#111111] text-[#A0A0A0] rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-white text-black font-bold rounded-xl text-xs hover:bg-neutral-200"
              >
                Publish Project
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Create Internship Modal */}
      {showCreateInternModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <form onSubmit={handleCreateInternship} className="w-full max-w-lg bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 text-white space-y-4 max-h-[85vh] overflow-y-auto">
            <h3 className="text-base font-bold text-white">Create New Internship Role</h3>
            
            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[#A0A0A0] mb-1">Role Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. AI Research Intern"
                  value={newIntern.role}
                  onChange={e => setNewIntern({ ...newIntern, role: e.target.value })}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#A0A0A0] mb-1">Monthly Stipend</label>
                  <input
                    type="text"
                    value={newIntern.stipend}
                    onChange={e => setNewIntern({ ...newIntern, stipend: e.target.value })}
                    className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                  />
                </div>
                <div>
                  <label className="block text-[#A0A0A0] mb-1">Openings</label>
                  <input
                    type="number"
                    value={newIntern.openings}
                    onChange={e => setNewIntern({ ...newIntern, openings: parseInt(e.target.value) || 1 })}
                    className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[#A0A0A0] mb-1">Tech Stack</label>
                <input
                  type="text"
                  value={newIntern.techStack}
                  onChange={e => setNewIntern({ ...newIntern, techStack: e.target.value })}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white"
                />
              </div>
              <div>
                <label className="block text-[#A0A0A0] mb-1">Role Overview</label>
                <textarea
                  rows={2}
                  value={newIntern.overview}
                  onChange={e => setNewIntern({ ...newIntern, overview: e.target.value })}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white resize-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCreateInternModal(false)}
                className="px-4 py-2 bg-[#111111] text-[#A0A0A0] rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-white text-black font-bold rounded-xl text-xs hover:bg-neutral-200"
              >
                Publish Internship
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
