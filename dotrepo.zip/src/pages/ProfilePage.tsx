import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useBookmarks } from '../context/BookmarkContext';
import { useToast } from '../context/ToastContext';
import { Application, Certificate, Project, Internship } from '../types';
import {
  User as UserIcon,
  Briefcase,
  FolderGit2,
  Award,
  Bell,
  Settings,
  Bookmark,
  ExternalLink,
  ShieldCheck,
  Calendar,
  Clock,
  LogOut,
  Edit2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { INITIAL_CERTIFICATES, INITIAL_PROJECTS, INITIAL_INTERNSHIPS } from '../data/initialData';
import { CertificateModal } from '../components/CertificateModal';

export const ProfilePage: React.FC = () => {
  const { user, isAuthenticated, logout, updateUser } = useAuth();
  const { bookmarkedIds } = useBookmarks();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'applications' | 'bookmarks' | 'certificates' | 'notifications' | 'settings'>('applications');
  
  const [applications, setApplications] = useState<Application[]>([]);
  const [loadingApps, setLoadingApps] = useState(true);
  const [selectedCert, setSelectedCert] = useState<Certificate | null>(null);

  // Edit Profile State
  const [editMode, setEditMode] = useState(false);
  const [profileForm, setProfileForm] = useState({
    name: user?.name || 'Alex Mercer',
    email: user?.email || 'student@dotrepo.org',
    college: user?.college || 'Stanford University',
    degree: user?.degree || 'B.S. Computer Science',
    cgpa: user?.cgpa || '3.85',
    github: user?.github || 'https://github.com/alexmercer',
    linkedin: user?.linkedin || 'https://linkedin.com/in/alexmercer',
    bio: user?.bio || 'Passionate full-stack developer focusing on AI systems and UI design.'
  });

  useEffect(() => {
    fetchApplications();
  }, [user]);

  const fetchApplications = async () => {
    setLoadingApps(true);
    try {
      const emailParam = user?.email ? `?email=${encodeURIComponent(user.email)}` : '';
      const res = await fetch(`/api/applications${emailParam}`);
      const data = await res.json();
      setApplications(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error('Error fetching applications:', err);
    } finally {
      setLoadingApps(false);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUser(profileForm);
    setEditMode(false);
    showToast('Profile Updated!', 'Your personal information has been saved.', 'success');
  };

  // Filter bookmarked items
  const savedProjects = INITIAL_PROJECTS.filter(p => bookmarkedIds.includes(p.id));
  const savedInternships = INITIAL_INTERNSHIPS.filter(i => bookmarkedIds.includes(i.id));

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <UserIcon className="w-12 h-12 text-[#666] mx-auto" />
        <h2 className="text-2xl font-bold text-white">Sign In Required</h2>
        <p className="text-xs text-[#A0A0A0]">Please sign in to view your dashboard, applications, and verified certificates.</p>
        <a
          href="/login"
          className="inline-block px-6 py-2.5 bg-white text-black font-bold rounded-xl text-xs hover:bg-neutral-200"
        >
          Sign In Now
        </a>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Header Profile Card */}
      <div className="bg-[#111111] border border-[#2A2A2A] rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="relative group">
            <img
              src={user?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=200&auto=format&fit=crop'}
              alt={user?.name}
              className="w-20 h-20 rounded-2xl object-cover border-2 border-white/20"
            />
            <button
              onClick={() => showToast('Avatar Update', 'Drag and drop new avatar image in Settings.', 'info')}
              className="absolute inset-0 bg-black/60 rounded-2xl opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-[10px] font-semibold transition-opacity"
            >
              Change
            </button>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-white">{user?.name}</h1>
              <span className="bg-[#161616] text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded border border-emerald-500/20">
                Verified Student
              </span>
            </div>
            <p className="text-xs text-[#A0A0A0]">{user?.college} • {user?.degree}</p>
            <p className="text-xs text-[#666666] font-mono">{user?.email}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setEditMode(!editMode)}
            className="px-4 py-2 bg-[#161616] hover:bg-[#222222] border border-[#2A2A2A] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Edit2 className="w-3.5 h-3.5" /> Edit Profile
          </button>
          <button
            onClick={logout}
            className="p-2 bg-[#161616] hover:bg-rose-950/40 border border-[#2A2A2A] text-rose-400 hover:text-rose-300 rounded-xl transition-colors"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Edit Profile Drawer / Form if open */}
      {editMode && (
        <form onSubmit={handleSaveProfile} className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-4 animate-in fade-in duration-150">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Update Profile Information</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-[#A0A0A0] mb-1">Full Name</label>
              <input
                type="text"
                value={profileForm.name}
                onChange={e => setProfileForm({ ...profileForm, name: e.target.value })}
                className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[#A0A0A0] mb-1">College</label>
              <input
                type="text"
                value={profileForm.college}
                onChange={e => setProfileForm({ ...profileForm, college: e.target.value })}
                className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[#A0A0A0] mb-1">Degree</label>
              <input
                type="text"
                value={profileForm.degree}
                onChange={e => setProfileForm({ ...profileForm, degree: e.target.value })}
                className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[#A0A0A0] mb-1">GitHub URL</label>
              <input
                type="url"
                value={profileForm.github}
                onChange={e => setProfileForm({ ...profileForm, github: e.target.value })}
                className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white focus:outline-none"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-[#A0A0A0] mb-1">Bio</label>
              <textarea
                rows={2}
                value={profileForm.bio}
                onChange={e => setProfileForm({ ...profileForm, bio: e.target.value })}
                className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-2.5 text-white focus:outline-none resize-none"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setEditMode(false)}
              className="px-4 py-2 bg-[#111111] text-[#A0A0A0] rounded-xl text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-white text-black font-bold rounded-xl text-xs hover:bg-neutral-200"
            >
              Save Changes
            </button>
          </div>
        </form>
      )}

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-[#2A2A2A] pb-2 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('applications')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl flex items-center gap-2 transition-colors shrink-0 ${
            activeTab === 'applications'
              ? 'bg-white text-black font-bold'
              : 'text-[#A0A0A0] hover:text-white hover:bg-[#161616]'
          }`}
        >
          <Briefcase className="w-3.5 h-3.5" />
          <span>My Applications ({applications.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('bookmarks')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl flex items-center gap-2 transition-colors shrink-0 ${
            activeTab === 'bookmarks'
              ? 'bg-white text-black font-bold'
              : 'text-[#A0A0A0] hover:text-white hover:bg-[#161616]'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          <span>Saved Items ({bookmarkedIds.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('certificates')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl flex items-center gap-2 transition-colors shrink-0 ${
            activeTab === 'certificates'
              ? 'bg-white text-black font-bold'
              : 'text-[#A0A0A0] hover:text-white hover:bg-[#161616]'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>Certificates & Badges ({INITIAL_CERTIFICATES.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('notifications')}
          className={`px-4 py-2 text-xs font-semibold rounded-xl flex items-center gap-2 transition-colors shrink-0 ${
            activeTab === 'notifications'
              ? 'bg-white text-black font-bold'
              : 'text-[#A0A0A0] hover:text-white hover:bg-[#161616]'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>Notifications</span>
        </button>
      </div>

      {/* TAB 1: APPLICATIONS TRACKER */}
      {activeTab === 'applications' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Application Status Tracker</h3>
          {loadingApps ? (
            <div className="h-40 bg-[#161616] rounded-2xl animate-pulse" />
          ) : applications.length === 0 ? (
            <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-10 text-center space-y-2">
              <p className="text-xs text-[#A0A0A0]">You haven't submitted any applications yet.</p>
              <a href="/projects" className="inline-block text-xs font-bold text-white underline pt-1">
                Explore Projects & Apply
              </a>
            </div>
          ) : (
            <div className="space-y-4">
              {applications.map(app => (
                <div
                  key={app.id}
                  className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#2A2A2A] pb-3">
                    <div>
                      <span className="text-[10px] font-mono text-[#A0A0A0]">Ref Code: {app.referenceId}</span>
                      <h4 className="text-base font-bold text-white mt-0.5">{app.itemTitle}</h4>
                      <p className="text-xs text-[#A0A0A0]">{app.itemType} • {app.domain}</p>
                    </div>

                    <div className="self-start sm:self-center">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                          app.status === 'Applied'
                            ? 'bg-blue-950/60 text-blue-300 border-blue-500/30'
                            : app.status === 'Shortlisted'
                            ? 'bg-purple-950/60 text-purple-300 border-purple-500/30'
                            : app.status === 'Scheduled Interview'
                            ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/30 animate-pulse'
                            : app.status === 'Accepted'
                            ? 'bg-emerald-900/80 text-white border-emerald-400'
                            : 'bg-neutral-900 text-[#888888] border-[#333]'
                        }`}
                      >
                        {app.status}
                      </span>
                    </div>
                  </div>

                  {/* Interview Alert Box if scheduled */}
                  {app.interviewDetails && (
                    <div className="bg-[#111111] border border-emerald-500/30 p-4 rounded-xl text-xs space-y-2">
                      <div className="flex items-center gap-2 text-emerald-400 font-bold">
                        <Calendar className="w-4 h-4" />
                        <span>Interview Scheduled</span>
                      </div>
                      <p className="text-[#A0A0A0]">
                        Date: <span className="text-white font-semibold">{app.interviewDetails.date} at {app.interviewDetails.time}</span>
                      </p>
                      {app.interviewDetails.notes && (
                        <p className="text-[#A0A0A0]">Note: {app.interviewDetails.notes}</p>
                      )}
                      <a
                        href={app.interviewDetails.link}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-block px-3 py-1.5 bg-emerald-500 text-black font-bold rounded-lg text-xs hover:bg-emerald-400"
                      >
                        Join Meeting Room
                      </a>
                    </div>
                  )}

                  <div className="text-[11px] text-[#666666] flex justify-between items-center">
                    <span>Applied on: {new Date(app.appliedAt).toLocaleDateString()}</span>
                    <span>Applicant Email: {app.email}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: BOOKMARKS */}
      {activeTab === 'bookmarks' && (
        <div className="space-y-6">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Bookmarked Projects & Internships</h3>
          
          {savedProjects.length === 0 && savedInternships.length === 0 ? (
            <p className="text-xs text-[#A0A0A0]">No bookmarked items yet. Bookmark projects or internships to view them here.</p>
          ) : (
            <div className="space-y-6">
              {savedProjects.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold text-[#A0A0A0] mb-3">Saved Projects</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {savedProjects.map(p => (
                      <div key={p.id} className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-center justify-between">
                        <div>
                          <h5 className="text-xs font-bold text-white">{p.name}</h5>
                          <span className="text-[10px] text-[#A0A0A0]">{p.domain} • {p.duration}</span>
                        </div>
                        <a href={`/projects/${p.id}`} className="text-xs text-white underline">View</a>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {savedInternships.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold text-[#A0A0A0] mb-3">Saved Internships</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {savedInternships.map(i => (
                      <div key={i.id} className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-center justify-between">
                        <div>
                          <h5 className="text-xs font-bold text-white">{i.role}</h5>
                          <span className="text-[10px] text-[#A0A0A0]">{i.company} • {i.stipend}</span>
                        </div>
                        <a href={`/internships/${i.id}`} className="text-xs text-white underline">View</a>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: CERTIFICATES */}
      {activeTab === 'certificates' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Earned Credentials</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {INITIAL_CERTIFICATES.map(cert => (
              <div key={cert.id} className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-[#A0A0A0] border border-[#2A2A2A] px-2 py-0.5 rounded">
                    {cert.certificateNumber}
                  </span>
                  <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Verified
                  </span>
                </div>

                <div>
                  <h4 className="text-base font-bold text-white">{cert.title}</h4>
                  <p className="text-xs text-[#A0A0A0] mt-0.5">Issued To: {cert.issuedTo} • Date: {cert.issueDate}</p>
                </div>

                <button
                  onClick={() => setSelectedCert(cert)}
                  className="w-full py-2 bg-white text-black font-bold rounded-xl text-xs hover:bg-neutral-200 transition-colors"
                >
                  View & Download Certificate
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: NOTIFICATIONS */}
      {activeTab === 'notifications' && (
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Notifications Log</h3>
          <div className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl text-xs space-y-1">
            <h5 className="font-bold text-white">Application DR-8942 Update</h5>
            <p className="text-[#A0A0A0]">Your application for "Autonomous Multi-Agent AI System" has been Shortlisted!</p>
            <span className="text-[10px] text-[#666]">2 hours ago</span>
          </div>
          <div className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl text-xs space-y-1">
            <h5 className="font-bold text-white">New Internship Cohort Live</h5>
            <p className="text-[#A0A0A0]">DotRepo launched Frontend Engineering Internships for React 19 track.</p>
            <span className="text-[10px] text-[#666]">1 day ago</span>
          </div>
        </div>
      )}

      {/* Certificate Viewer Modal */}
      <CertificateModal
        isOpen={!!selectedCert}
        onClose={() => setSelectedCert(null)}
        certificate={selectedCert}
      />

    </div>
  );
};
