import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Clock,
  Users,
  ShieldCheck,
  Sparkles,
  Calendar,
  CheckCircle2,
  ChevronDown,
  Building2,
  Bookmark,
  Share2
} from 'lucide-react';
import { Project } from '../types';
import { useBookmarks } from '../context/BookmarkContext';
import { useToast } from '../context/ToastContext';

interface ProjectDetailsPageProps {
  onApplyProject: (project: Project) => void;
}

export const ProjectDetailsPage: React.FC<ProjectDetailsPageProps> = ({ onApplyProject }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { isBookmarked, toggleBookmark } = useBookmarks();

  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  useEffect(() => {
    if (id) {
      fetchProjectDetails(id);
    }
  }, [id]);

  const fetchProjectDetails = async (projId: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/projects/${projId}`);
      if (!res.ok) {
        setProject(null);
        return;
      }
      const data = await res.json();
      setProject(data);
    } catch (err) {
      console.error('Error fetching project details:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    showToast('Link Copied!', 'Project URL copied to clipboard.', 'success');
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-20">
        <div className="h-96 bg-[#161616] rounded-2xl animate-pulse border border-[#2A2A2A]" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-white">Project Not Found</h2>
        <p className="text-xs text-[#A0A0A0]">The requested project cohort may have ended or moved.</p>
        <Link
          to="/projects"
          className="inline-block px-5 py-2.5 bg-white text-black font-semibold rounded-xl text-xs hover:bg-neutral-200"
        >
          Back to Projects List
        </Link>
      </div>
    );
  }

  const bookmarked = isBookmarked(project.id);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      
      {/* Back Link */}
      <button
        onClick={() => navigate('/projects')}
        className="flex items-center gap-2 text-xs font-semibold text-[#A0A0A0] hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Projects
      </button>

      {/* Hero Header Banner */}
      <div className="bg-[#111111] border border-[#2A2A2A] rounded-3xl p-6 sm:p-10 space-y-6 relative overflow-hidden">
        <div className="flex flex-wrap items-center gap-2">
          <span className="bg-white text-black font-bold text-xs px-3 py-1 rounded-full">
            {project.domain}
          </span>
          <span className="bg-[#161616] text-[#A0A0A0] border border-[#2A2A2A] text-xs px-3 py-1 rounded-full">
            {project.difficulty} Level
          </span>
          <span className="bg-[#161616] text-emerald-400 border border-emerald-500/20 text-xs px-3 py-1 rounded-full flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> Certified Cohort
          </span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
          {project.name}
        </h1>

        <p className="text-sm text-[#A0A0A0] leading-relaxed max-w-3xl">
          {project.overview}
        </p>

        {/* Quick Attributes Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-[#2A2A2A] text-xs">
          <div>
            <span className="text-[#666] block">Duration & Timeline</span>
            <span className="text-white font-semibold mt-0.5 block">{project.duration} ({project.timeline})</span>
          </div>
          <div>
            <span className="text-[#666] block">Cohort Team Size</span>
            <span className="text-white font-semibold mt-0.5 block">{project.teamSize}</span>
          </div>
          <div>
            <span className="text-[#666] block">Work Mode</span>
            <span className="text-white font-semibold mt-0.5 block">{project.mode}</span>
          </div>
          <div>
            <span className="text-[#666] block">Application Deadline</span>
            <span className="text-white font-semibold mt-0.5 block">{project.deadline}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-4 flex flex-wrap items-center gap-3">
          <button
            onClick={() => onApplyProject(project)}
            className="px-8 py-3.5 bg-white text-black font-extrabold rounded-xl text-sm hover:bg-neutral-200 transition-colors shadow-xl"
          >
            Apply for Project Cohort
          </button>
          
          <button
            onClick={() => toggleBookmark(project.id)}
            className="px-4 py-3.5 bg-[#161616] hover:bg-[#222222] border border-[#2A2A2A] text-white rounded-xl text-xs font-semibold flex items-center gap-2"
          >
            <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-white' : ''}`} />
            <span>{bookmarked ? 'Bookmarked' : 'Bookmark'}</span>
          </button>

          <button
            onClick={handleShare}
            className="p-3.5 bg-[#161616] hover:bg-[#222222] border border-[#2A2A2A] text-[#A0A0A0] hover:text-white rounded-xl"
            title="Share Project Link"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Main Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Details & Tasks */}
        <div className="lg:col-span-2 space-y-10">
          
          {/* Detailed Description */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-white uppercase tracking-wider">Project Description</h3>
            <p className="text-sm text-[#A0A0A0] leading-relaxed">
              {project.description}
            </p>
          </div>

          {/* Learning Outcomes */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white uppercase tracking-wider">Learning Outcomes</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {project.learningOutcomes.map((outcome, idx) => (
                <div key={idx} className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="text-xs text-[#A0A0A0] leading-relaxed">{outcome}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Milestones & Tasks Breakdown */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white uppercase tracking-wider">Sprint Deliverables & Tasks</h3>
            <div className="space-y-3">
              {project.tasks.map((t, idx) => (
                <div key={idx} className="bg-[#111111] border border-[#2A2A2A] p-4 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Week {t.week}: {t.title}</span>
                    <span className="text-[10px] bg-[#161616] border border-[#2A2A2A] text-[#A0A0A0] px-2 py-0.5 rounded">
                      Sprint Milestone
                    </span>
                  </div>
                  <p className="text-xs text-[#A0A0A0]">{t.detail}</p>
                </div>
              ))}
            </div>
          </div>

          {/* FAQs Accordion */}
          {project.faqs && project.faqs.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-white uppercase tracking-wider">Project FAQs</h3>
              <div className="space-y-2">
                {project.faqs.map((f, idx) => {
                  const isOpen = openFaq === idx;
                  return (
                    <div key={idx} className="bg-[#161616] border border-[#2A2A2A] rounded-xl overflow-hidden">
                      <button
                        onClick={() => setOpenFaq(isOpen ? null : idx)}
                        className="w-full p-4 text-left flex items-center justify-between text-xs font-bold text-white"
                      >
                        <span>{f.question}</span>
                        <ChevronDown className={`w-4 h-4 text-[#A0A0A0] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                      </button>
                      {isOpen && (
                        <p className="px-4 pb-4 text-xs text-[#A0A0A0] leading-relaxed border-t border-[#2A2A2A] pt-3">
                          {f.answer}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>

        {/* Right Sidebar: Tech Stack, Mentor, Certificate */}
        <div className="space-y-6">
          
          {/* Tech Stack Box */}
          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-4">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Technology Stack</h4>
            <div className="flex flex-wrap gap-2">
              {project.techStack.map(t => (
                <span key={t} className="bg-[#111111] text-white border border-[#2A2A2A] text-xs px-3 py-1 rounded-lg">
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* Assigned Mentor Box */}
          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-4">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Assigned Lead Mentor</h4>
            <div className="flex items-center gap-3">
              <img
                src={project.mentor.avatar}
                alt={project.mentor.name}
                className="w-12 h-12 rounded-xl object-cover border border-[#2A2A2A]"
              />
              <div>
                <h5 className="text-sm font-bold text-white">{project.mentor.name}</h5>
                <p className="text-xs text-[#A0A0A0]">{project.mentor.title}</p>
                <span className="text-[10px] text-[#888888]">{project.mentor.company}</span>
              </div>
            </div>
          </div>

          {/* Certificate Guarantee Box */}
          <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-6 space-y-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <h4 className="text-sm font-bold text-white">Verified Certificate</h4>
            </div>
            <p className="text-xs text-[#A0A0A0] leading-relaxed">
              Upon successful completion and code audit, you receive a cryptographically verified DotRepo certificate.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};
