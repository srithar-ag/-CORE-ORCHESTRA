import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Building2,
  Calendar,
  Award,
  FileCheck,
  CheckCircle2,
  Bookmark,
  Share2,
  Users
} from 'lucide-react';
import { Internship } from '../types';
import { useBookmarks } from '../context/BookmarkContext';
import { useToast } from '../context/ToastContext';

interface InternshipDetailsPageProps {
  onApplyInternship: (internship: Internship) => void;
}

export const InternshipDetailsPage: React.FC<InternshipDetailsPageProps> = ({
  onApplyInternship,
}) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { isBookmarked, toggleBookmark } = useBookmarks();

  const [internship, setInternship] = useState<Internship | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) fetchInternshipDetails(id);
  }, [id]);

  const fetchInternshipDetails = async (internId: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/internships/${internId}`);
      if (!res.ok) {
        setInternship(null);
        return;
      }
      const data = await res.json();
      setInternship(data);
    } catch (err) {
      console.error('Error fetching internship:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    showToast('Link Copied!', 'Internship URL copied to clipboard.', 'success');
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-20">
        <div className="h-96 bg-[#161616] rounded-2xl animate-pulse border border-[#2A2A2A]" />
      </div>
    );
  }

  if (!internship) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-white">Internship Position Not Found</h2>
        <p className="text-xs text-[#A0A0A0]">This opening may have closed or expired.</p>
        <Link
          to="/internships"
          className="inline-block px-5 py-2.5 bg-white text-black font-semibold rounded-xl text-xs hover:bg-neutral-200"
        >
          Back to Internships
        </Link>
      </div>
    );
  }

  const bookmarked = isBookmarked(internship.id);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      
      {/* Back Link */}
      <button
        onClick={() => navigate('/internships')}
        className="flex items-center gap-2 text-xs font-semibold text-[#A0A0A0] hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Internships
      </button>

      {/* Header Banner */}
      <div className="bg-[#111111] border border-[#2A2A2A] rounded-3xl p-6 sm:p-10 space-y-6">
        <div className="flex flex-wrap items-center gap-2">
          <span className="bg-white text-black font-bold text-xs px-3 py-1 rounded-full flex items-center gap-1">
            <Building2 className="w-3.5 h-3.5" /> {internship.company} Core
          </span>
          <span className="bg-[#161616] text-[#A0A0A0] border border-[#2A2A2A] text-xs px-3 py-1 rounded-full">
            {internship.mode}
          </span>
          <span className="bg-[#161616] text-purple-400 border border-purple-500/20 text-xs px-3 py-1 rounded-full flex items-center gap-1">
            <FileCheck className="w-3.5 h-3.5" /> Includes LOR & Certificate
          </span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
          {internship.role}
        </h1>

        <p className="text-sm text-[#A0A0A0] leading-relaxed max-w-3xl">
          {internship.overview}
        </p>

        {/* Highlights Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-[#2A2A2A] text-xs">
          <div>
            <span className="text-[#666] block">Monthly Stipend</span>
            <span className="text-white font-semibold mt-0.5 block">{internship.stipend}</span>
          </div>
          <div>
            <span className="text-[#666] block">Program Duration</span>
            <span className="text-white font-semibold mt-0.5 block">{internship.duration}</span>
          </div>
          <div>
            <span className="text-[#666] block">Available Openings</span>
            <span className="text-white font-semibold mt-0.5 block">{internship.openings} Seats</span>
          </div>
          <div>
            <span className="text-[#666] block">Application Deadline</span>
            <span className="text-white font-semibold mt-0.5 block">{internship.deadline}</span>
          </div>
        </div>

        {/* Action CTAs */}
        <div className="pt-4 flex flex-wrap items-center gap-3">
          <button
            onClick={() => onApplyInternship(internship)}
            className="px-8 py-3.5 bg-white text-black font-extrabold rounded-xl text-sm hover:bg-neutral-200 transition-colors shadow-xl"
          >
            Apply for Internship
          </button>
          
          <button
            onClick={() => toggleBookmark(internship.id)}
            className="px-4 py-3.5 bg-[#161616] hover:bg-[#222222] border border-[#2A2A2A] text-white rounded-xl text-xs font-semibold flex items-center gap-2"
          >
            <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-white' : ''}`} />
            <span>{bookmarked ? 'Bookmarked' : 'Bookmark'}</span>
          </button>

          <button
            onClick={handleShare}
            className="p-3.5 bg-[#161616] hover:bg-[#222222] border border-[#2A2A2A] text-[#A0A0A0] hover:text-white rounded-xl"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Main Grid Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <div className="lg:col-span-2 space-y-10">
          
          {/* Key Responsibilities */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white uppercase tracking-wider">Key Responsibilities</h3>
            <div className="space-y-2.5">
              {internship.responsibilities.map((resp, idx) => (
                <div key={idx} className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="text-xs text-[#A0A0A0] leading-relaxed">{resp}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Requirements */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white uppercase tracking-wider">Role Requirements</h3>
            <div className="space-y-2.5">
              {internship.requirements.map((req, idx) => (
                <div key={idx} className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-start gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-white mt-2 shrink-0" />
                  <span className="text-xs text-[#A0A0A0] leading-relaxed">{req}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Selection Process Roadmap */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white uppercase tracking-wider">Selection Process</h3>
            <div className="space-y-3">
              {internship.selectionProcess.map((step) => (
                <div key={step.step} className="bg-[#111111] border border-[#2A2A2A] p-4 rounded-xl flex items-start gap-4">
                  <div className="w-7 h-7 rounded-lg bg-white text-black font-bold text-xs flex items-center justify-center shrink-0">
                    {step.step}
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">{step.title}</h5>
                    <p className="text-xs text-[#A0A0A0] mt-0.5">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Performance Review Policy */}
          <div className="bg-[#111111] border border-[#2A2A2A] p-6 rounded-2xl space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Performance Review & LOR</h4>
            <p className="text-xs text-[#A0A0A0] leading-relaxed">
              {internship.performanceReview}
            </p>
          </div>

        </div>

        {/* Right Sidebar */}
        <div className="space-y-6">
          
          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-4">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Technology Stack</h4>
            <div className="flex flex-wrap gap-2">
              {internship.techStack.map(t => (
                <span key={t} className="bg-[#111111] text-white border border-[#2A2A2A] text-xs px-3 py-1 rounded-lg">
                  {t}
                </span>
              ))}
            </div>
          </div>

          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-3">
            <Award className="w-6 h-6 text-emerald-400" />
            <h4 className="text-sm font-bold text-white">Verified Credentials</h4>
            <p className="text-xs text-[#A0A0A0] leading-relaxed">
              All interns who complete their tenure receive an official Certificate of Completion and Letter of Recommendation.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};
