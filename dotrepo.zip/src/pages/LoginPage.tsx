import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Lock, Mail, UserCheck, Shield, ArrowRight } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const { showToast } = useToast();

  const [roleMode, setRoleMode] = useState<'student' | 'admin'>('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    const loginEmail = roleMode === 'admin' ? (email || 'admin@dotrepo.org') : (email || 'student@dotrepo.org');
    const success = await login(loginEmail, password);
    setSubmitting(false);

    if (success) {
      showToast('Authenticated', `Welcome back to DotRepo ${roleMode === 'admin' ? 'Admin' : 'Studio'}!`, 'success');
      navigate(roleMode === 'admin' ? '/admin' : '/profile');
    } else {
      showToast('Authentication Error', 'Invalid credentials or connection issue.', 'error');
    }
  };

  const handleDemoStudent = async () => {
    setSubmitting(true);
    const success = await login('student@dotrepo.org', 'demo123');
    setSubmitting(false);
    if (success) {
      showToast('Student Demo Mode', 'Logged in as Alex Mercer.', 'success');
      navigate('/profile');
    }
  };

  const handleDemoAdmin = async () => {
    setSubmitting(true);
    const success = await login('admin@dotrepo.org', 'admin123');
    setSubmitting(false);
    if (success) {
      showToast('Admin Demo Mode', 'Logged in as Admin Command.', 'success');
      navigate('/admin');
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16 space-y-8">
      
      {/* Brand Header */}
      <div className="text-center space-y-2">
        <div className="w-12 h-12 rounded-2xl bg-white text-black font-bold flex items-center justify-center text-xl mx-auto border border-white">
          .R
        </div>
        <h1 className="text-2xl font-extrabold text-white">Sign In to DotRepo</h1>
        <p className="text-xs text-[#A0A0A0]">Access your project cohorts, applications, and verified credentials.</p>
      </div>

      {/* Role Switcher Pills */}
      <div className="bg-[#111111] p-1.5 border border-[#2A2A2A] rounded-2xl flex items-center gap-1 text-xs">
        <button
          onClick={() => {
            setRoleMode('student');
            setEmail('student@dotrepo.org');
          }}
          className={`flex-1 py-2 rounded-xl font-semibold transition-colors flex items-center justify-center gap-1.5 ${
            roleMode === 'student' ? 'bg-white text-black' : 'text-[#A0A0A0] hover:text-white'
          }`}
        >
          <UserCheck className="w-3.5 h-3.5" /> Student Login
        </button>

        <button
          onClick={() => {
            setRoleMode('admin');
            setEmail('admin@dotrepo.org');
          }}
          className={`flex-1 py-2 rounded-xl font-semibold transition-colors flex items-center justify-center gap-1.5 ${
            roleMode === 'admin' ? 'bg-white text-black' : 'text-[#A0A0A0] hover:text-white'
          }`}
        >
          <Shield className="w-3.5 h-3.5" /> Admin Command
        </button>
      </div>

      {/* Login Card */}
      <form onSubmit={handleSubmit} className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-4">
        <div>
          <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Email Address</label>
          <div className="relative">
            <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#A0A0A0]" />
            <input
              type="email"
              required
              placeholder={roleMode === 'admin' ? 'admin@dotrepo.org' : 'student@dotrepo.org'}
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl pl-9 pr-3 py-2.5 text-xs text-white focus:outline-none focus:border-white"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Password</label>
          <div className="relative">
            <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#A0A0A0]" />
            <input
              type="password"
              required
              placeholder="••••••••"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl pl-9 pr-3 py-2.5 text-xs text-white focus:outline-none focus:border-white"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full py-3 bg-white text-black font-bold text-xs rounded-xl hover:bg-neutral-200 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
        >
          <span>{submitting ? 'Authenticating...' : `Sign In as ${roleMode === 'admin' ? 'Admin' : 'Student'}`}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>

        {/* Demo One-Click Fill Buttons */}
        <div className="pt-4 border-t border-[#2A2A2A] space-y-2">
          <span className="text-[10px] text-[#A0A0A0] uppercase tracking-wider block text-center font-semibold">
            One-Click Demo Account Access
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleDemoStudent}
              className="py-2 bg-[#111111] hover:bg-[#222222] border border-[#2A2A2A] text-white text-[11px] font-semibold rounded-xl"
            >
              Student Demo
            </button>
            <button
              type="button"
              onClick={handleDemoAdmin}
              className="py-2 bg-[#111111] hover:bg-[#222222] border border-[#2A2A2A] text-emerald-400 text-[11px] font-semibold rounded-xl"
            >
              Admin Demo
            </button>
          </div>
        </div>
      </form>

    </div>
  );
};
