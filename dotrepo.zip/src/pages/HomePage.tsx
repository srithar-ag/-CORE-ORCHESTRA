import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import {
  ArrowRight,
  Sparkles,
  Terminal,
  Layers,
  Award,
  ShieldCheck,
  CheckCircle2,
  ChevronDown,
  Users,
  Briefcase,
  FolderGit2,
  Cpu,
  GraduationCap
} from 'lucide-react';
import {
  INITIAL_PROJECTS,
  INITIAL_INTERNSHIPS,
  COMPANY_LOGOS,
  STATS_DATA,
  TESTIMONIALS,
  FAQ_ITEMS
} from '../data/initialData';
import { ProjectCard } from '../components/ProjectCard';
import { InternshipCard } from '../components/InternshipCard';
import { Project, Internship } from '../types';

interface HomePageProps {
  onApplyProject: (project: Project) => void;
  onApplyInternship: (internship: Internship) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onApplyProject, onApplyInternship }) => {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<string | null>('faq-1');

  // Animated Counters
  const [counts, setCounts] = useState(STATS_DATA.map(() => 0));

  useEffect(() => {
    const timer = setTimeout(() => {
      setCounts(STATS_DATA.map(s => s.value));
    }, 200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="space-y-24 pb-20">
      
      {/* HERO SECTION */}
      <section className="relative pt-12 sm:pt-20 pb-16 flex flex-col items-center text-center px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        
        {/* Top Tagline Badge */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#161616] border border-[#2A2A2A] text-xs font-medium text-white mb-8 shadow-inner"
        >
          <Sparkles className="w-3.5 h-3.5 text-white" />
          <span>The Premier Software Talent Accelerator</span>
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
        </motion.div>

        {/* Main Hero Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.08]"
        >
          Designing and Building Products for Meaningful Real-World Impact.
        </motion.h1>

        {/* Hero Description */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-6 text-base sm:text-xl text-[#A0A0A0] max-w-2xl leading-relaxed font-normal"
        >
          DotRepo connects ambitious developers with production-grade industry software projects, expert engineering mentorship, and paid remote internships.
        </motion.p>

        {/* Action CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto"
        >
          <button
            onClick={() => navigate('/projects')}
            className="w-full sm:w-auto px-8 py-3.5 bg-white text-black hover:bg-neutral-200 font-bold rounded-xl text-sm transition-all duration-200 shadow-xl hover:scale-102 flex items-center justify-center gap-2"
          >
            <span>Explore Projects</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          
          <button
            onClick={() => navigate('/internships')}
            className="w-full sm:w-auto px-8 py-3.5 bg-[#161616] hover:bg-[#222222] text-white border border-[#2A2A2A] font-semibold rounded-xl text-sm transition-all duration-200 flex items-center justify-center gap-2"
          >
            <Briefcase className="w-4 h-4" />
            <span>Explore Internships</span>
          </button>
        </motion.div>

        {/* Terminal Code Snippet Preview */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="mt-14 w-full max-w-3xl bg-[#111111] border border-[#2A2A2A] rounded-2xl p-4 sm:p-6 text-left font-mono text-xs text-[#A0A0A0] shadow-2xl relative group"
        >
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-3 mb-4">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-[#333333]" />
              <span className="w-3 h-3 rounded-full bg-[#333333]" />
              <span className="w-3 h-3 rounded-full bg-[#333333]" />
              <span className="text-[11px] text-[#666666] ml-2">dotrepo-cli v2.6.0</span>
            </div>
            <span className="text-[10px] bg-[#161616] px-2 py-0.5 rounded text-white border border-[#2A2A2A]">
              production
            </span>
          </div>

          <div className="space-y-1.5 text-xs">
            <p className="text-white">$ dotrepo project init --domain AI --team 3</p>
            <p className="text-emerald-400">✓ Initialized: Autonomous Multi-Agent AI System</p>
            <p className="text-[#888888]">→ Provisioned Cloud GPU Sandbox (Nvidia A10G)</p>
            <p className="text-[#888888]">→ Connected Senior Mentor: Dr. Aris Thorne (DotRepo Labs)</p>
            <p className="text-white pt-2">$ dotrepo status --verify</p>
            <p className="text-emerald-400">✓ Verified Credentials Code: DR-CERT-2026-9812</p>
          </div>
        </motion.div>

      </section>

      {/* STATS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-8 grid grid-cols-2 lg:grid-cols-5 gap-6 text-center">
          {STATS_DATA.map((stat, idx) => (
            <div key={stat.label} className="space-y-1">
              <span className="text-3xl sm:text-4xl font-extrabold text-white font-mono tracking-tight">
                {counts[idx]}
                {stat.suffix}
              </span>
              <p className="text-xs text-[#A0A0A0] font-medium uppercase tracking-wider">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* SCROLLING COMPANY SHOWCASE */}
      <section className="overflow-hidden border-y border-[#2A2A2A] py-8 bg-[#000000]">
        <div className="max-w-7xl mx-auto px-4 mb-4 text-center">
          <span className="text-[11px] text-[#A0A0A0] uppercase tracking-widest font-semibold">
            DotRepo Alumni Engineering Placement & Mentorship Partners
          </span>
        </div>
        <div className="flex gap-12 whitespace-nowrap animate-marquee items-center justify-around opacity-60">
          {COMPANY_LOGOS.map((c) => (
            <span key={c.name} className="text-sm font-bold text-white tracking-widest px-4">
              {c.logo}
            </span>
          ))}
        </div>
      </section>

      {/* FEATURED PROJECTS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0] flex items-center gap-1.5">
              <FolderGit2 className="w-3.5 h-3.5 text-white" /> Production Cohorts
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              Featured Real-World Projects
            </h2>
          </div>
          <Link
            to="/projects"
            className="text-xs font-semibold text-white hover:text-neutral-300 flex items-center gap-1 bg-[#161616] border border-[#2A2A2A] px-4 py-2 rounded-xl transition-colors"
          >
            <span>View All Projects</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {INITIAL_PROJECTS.slice(0, 3).map((project) => (
            <ProjectCard key={project.id} project={project} onApply={onApplyProject} />
          ))}
        </div>
      </section>

      {/* FEATURED INTERNSHIPS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0] flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5 text-white" /> Career Openings
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              Featured Remote Internships
            </h2>
          </div>
          <Link
            to="/internships"
            className="text-xs font-semibold text-white hover:text-neutral-300 flex items-center gap-1 bg-[#161616] border border-[#2A2A2A] px-4 py-2 rounded-xl transition-colors"
          >
            <span>View All Internships</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {INITIAL_INTERNSHIPS.slice(0, 3).map((intern) => (
            <InternshipCard key={intern.id} internship={intern} onApply={onApplyInternship} />
          ))}
        </div>
      </section>

      {/* BENEFITS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0]">Why DotRepo</span>
          <h2 className="text-3xl font-extrabold text-white">
            Built for Engineers Who Demand Real Experience
          </h2>
          <p className="text-sm text-[#A0A0A0]">
            We bridge the gap between academic theory and enterprise engineering requirements.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-white text-black flex items-center justify-center font-bold">
              <Cpu className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Production Architectures</h3>
            <p className="text-xs text-[#A0A0A0] leading-relaxed">
              Work with real distributed databases, Kubernetes clusters, agentic AI frameworks, and high-frequency APIs.
            </p>
          </div>

          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-white text-black flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">1-on-1 Senior Mentorship</h3>
            <p className="text-xs text-[#A0A0A0] leading-relaxed">
              Receive pull-request code reviews from engineers at FAANG, Stripe, and leading AI labs.
            </p>
          </div>

          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-white text-black flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Verified Credentials & LOR</h3>
            <p className="text-xs text-[#A0A0A0] leading-relaxed">
              Earn cryptographically verifiable certificates and Letter of Recommendations that stand out to recruiters.
            </p>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS TIMELINE */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0]">Roadmap</span>
          <h2 className="text-3xl font-extrabold text-white">How DotRepo Cohorts Work</h2>
        </div>

        <div className="relative border-l-2 border-[#2A2A2A] ml-4 sm:ml-32 space-y-10 pl-6 sm:pl-8">
          
          <div className="relative">
            <div className="absolute -left-[31px] sm:-left-[39px] top-1 w-6 h-6 rounded-full bg-white text-black font-bold text-xs flex items-center justify-center">
              1
            </div>
            <h3 className="text-base font-bold text-white">Select Your Domain & Project</h3>
            <p className="text-xs text-[#A0A0A0] mt-1 leading-relaxed">
              Browse over 18+ domains ranging from AI Agents to Cyber Security and submit your application.
            </p>
          </div>

          <div className="relative">
            <div className="absolute -left-[31px] sm:-left-[39px] top-1 w-6 h-6 rounded-full bg-white text-black font-bold text-xs flex items-center justify-center">
              2
            </div>
            <h3 className="text-base font-bold text-white">Build Milestones & Receive Code Reviews</h3>
            <p className="text-xs text-[#A0A0A0] mt-1 leading-relaxed">
              Complete weekly sprints, push code to GitHub, and receive line-by-line feedback from your assigned mentor.
            </p>
          </div>

          <div className="relative">
            <div className="absolute -left-[31px] sm:-left-[39px] top-1 w-6 h-6 rounded-full bg-white text-black font-bold text-xs flex items-center justify-center">
              3
            </div>
            <h3 className="text-base font-bold text-white">Earn Verification & Direct Hiring Referral</h3>
            <p className="text-xs text-[#A0A0A0] mt-1 leading-relaxed">
              Receive a verified certificate, portfolio feature, and direct referral into paid DotRepo partner internships.
            </p>
          </div>

        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0]">Student Stories</span>
          <h2 className="text-3xl font-extrabold text-white">Loved by Developers Worldwide</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div key={t.id} className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-4 flex flex-col justify-between">
              <p className="text-xs text-[#A0A0A0] leading-relaxed italic">
                "{t.content}"
              </p>

              <div className="flex items-center gap-3 pt-4 border-t border-[#2A2A2A]">
                <img src={t.avatar} alt={t.name} className="w-10 h-10 rounded-full object-cover border border-[#333]" />
                <div>
                  <h4 className="text-xs font-bold text-white">{t.name}</h4>
                  <p className="text-[11px] text-[#A0A0A0]">{t.role} • {t.college}</p>
                  {t.companyPlacements && (
                    <span className="inline-block mt-1 text-[10px] bg-white/10 text-emerald-300 px-2 py-0.5 rounded border border-white/20">
                      {t.companyPlacements}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQS SECTION */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0]">Answers</span>
          <h2 className="text-3xl font-extrabold text-white">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-3">
          {FAQ_ITEMS.map((faq) => {
            const isOpen = openFaq === faq.id;
            return (
              <div
                key={faq.id}
                className="bg-[#161616] border border-[#2A2A2A] rounded-xl overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : faq.id)}
                  className="w-full p-4 text-left flex items-center justify-between text-sm font-semibold text-white hover:text-neutral-200"
                >
                  <span>{faq.question}</span>
                  <ChevronDown className={`w-4 h-4 text-[#A0A0A0] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 text-xs text-[#A0A0A0] leading-relaxed border-t border-[#2A2A2A]/50 pt-3">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#111111] border border-[#2A2A2A] rounded-3xl p-8 sm:p-12 text-center space-y-6 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-white/5 via-transparent to-white/5 pointer-events-none" />
          
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white max-w-2xl mx-auto tracking-tight">
            Ready to Build Real Software Products That Matter?
          </h2>
          
          <p className="text-sm text-[#A0A0A0] max-w-md mx-auto">
            Join the next cohort of DotRepo engineers. Applications are open for upcoming project cohorts and internships.
          </p>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/projects')}
              className="px-8 py-3.5 bg-white text-black font-bold text-sm rounded-xl hover:bg-neutral-200 transition-all flex items-center gap-2"
            >
              <span>Explore Projects</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
