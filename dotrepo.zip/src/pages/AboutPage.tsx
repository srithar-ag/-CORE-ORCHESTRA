import React, { useState } from 'react';
import { TEAM_MEMBERS, FAQ_ITEMS } from '../data/initialData';
import { Target, Compass, Heart, Shield, Send, CheckCircle2, ChevronDown, Linkedin, Github } from 'lucide-react';
import { useToast } from '../context/ToastContext';

export const AboutPage: React.FC = () => {
  const { showToast } = useToast();
  const [openFaq, setOpenFaq] = useState<string | null>('faq-1');

  // Contact Form State
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [sending, setSending] = useState(false);

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.email || !contactForm.message) {
      showToast('Missing Fields', 'Please fill in Name, Email, and Message.', 'error');
      return;
    }

    setSending(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(contactForm)
      });
      const data = await res.json();
      setSending(false);

      if (data.success) {
        showToast('Message Sent!', data.message, 'success');
        setContactForm({ name: '', email: '', subject: '', message: '' });
      }
    } catch (err) {
      setSending(false);
      showToast('Error Sending', 'Unable to reach contact endpoint.', 'error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-20">
      
      {/* Header Banner */}
      <section className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0]">About DotRepo</span>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
          Designing and Building Products for Meaningful Real-World Impact.
        </h1>
        <p className="text-sm sm:text-base text-[#A0A0A0] leading-relaxed">
          Founded by ex-Google and Stripe engineers, DotRepo is redefining software engineering education by replacing passive tutorial watching with active product engineering.
        </p>
      </section>

      {/* MISSION & VISION GRID */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-xl bg-white text-black font-bold flex items-center justify-center">
            <Target className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white">Our Mission</h3>
          <p className="text-xs text-[#A0A0A0] leading-relaxed">
            To democratize access to production software engineering. We empower every ambitious student to build real, scalable systems, receive line-by-line code audits, and enter top-tier tech careers.
          </p>
        </div>

        <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-xl bg-white text-black font-bold flex items-center justify-center">
            <Compass className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-white">Our Vision</h3>
          <p className="text-xs text-[#A0A0A0] leading-relaxed">
            To become the global standard for software credentials—where a verified DotRepo project or internship badge represents proof of engineering mastery recognized by top tech leaders.
          </p>
        </div>

      </section>

      {/* CORE VALUES */}
      <section className="space-y-8">
        <div className="text-center space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0]">Principles</span>
          <h2 className="text-3xl font-extrabold text-white">Our Core Values</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-2">
            <span className="text-xs font-mono text-white font-bold">01. Rigor</span>
            <h4 className="text-sm font-bold text-white">Zero Compromise Code</h4>
            <p className="text-xs text-[#A0A0A0] leading-relaxed">
              We enforce production standards, automated CI/CD checks, and thorough code reviews.
            </p>
          </div>

          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-2">
            <span className="text-xs font-mono text-white font-bold">02. Execution</span>
            <h4 className="text-sm font-bold text-white">Shipped Software</h4>
            <p className="text-xs text-[#A0A0A0] leading-relaxed">
              We value working code deployed to production over perfect theoretical documentation.
            </p>
          </div>

          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-2">
            <span className="text-xs font-mono text-white font-bold">03. Mentorship</span>
            <h4 className="text-sm font-bold text-white">Senior Guidance</h4>
            <p className="text-xs text-[#A0A0A0] leading-relaxed">
              Direct access to engineers who have built systems scaling to millions of users.
            </p>
          </div>

          <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-2">
            <span className="text-xs font-mono text-white font-bold">04. Integrity</span>
            <h4 className="text-sm font-bold text-white">Verified Merit</h4>
            <p className="text-xs text-[#A0A0A0] leading-relaxed">
              Transparent, tamper-proof credentials and honest performance evaluations.
            </p>
          </div>
        </div>
      </section>

      {/* MEET THE TEAM */}
      <section className="space-y-8">
        <div className="text-center space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0]">Leadership</span>
          <h2 className="text-3xl font-extrabold text-white">Meet the DotRepo Team</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {TEAM_MEMBERS.map((member) => (
            <div key={member.id} className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-6 space-y-4 text-center">
              <img
                src={member.avatar}
                alt={member.name}
                className="w-20 h-20 rounded-2xl object-cover mx-auto border border-[#333]"
              />
              <div>
                <h4 className="text-base font-bold text-white">{member.name}</h4>
                <p className="text-xs text-emerald-400 font-medium">{member.role}</p>
                <p className="text-xs text-[#A0A0A0] mt-2 line-clamp-3 leading-relaxed">
                  {member.bio}
                </p>
              </div>

              <div className="flex items-center justify-center gap-3 pt-2">
                <a
                  href={member.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1.5 text-[#A0A0A0] hover:text-white bg-[#111111] border border-[#2A2A2A] rounded-lg"
                >
                  <Linkedin className="w-3.5 h-3.5" />
                </a>
                {member.github && (
                  <a
                    href={member.github}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1.5 text-[#A0A0A0] hover:text-white bg-[#111111] border border-[#2A2A2A] rounded-lg"
                  >
                    <Github className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CONTACT FORM SECTION */}
      <section className="bg-[#111111] border border-[#2A2A2A] rounded-3xl p-8 sm:p-12 grid grid-cols-1 lg:grid-cols-2 gap-10">
        
        <div className="space-y-4">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0]">Get in Touch</span>
          <h2 className="text-3xl font-extrabold text-white">Have Questions or Want to Partner?</h2>
          <p className="text-xs text-[#A0A0A0] leading-relaxed">
            Whether you are a university representative, hiring manager, or aspiring developer, our admissions team is here to help.
          </p>

          <div className="pt-4 space-y-3 text-xs text-[#A0A0A0]">
            <div>
              <span className="text-white font-semibold block">Office Location</span>
              <span>San Francisco, CA & Remote Global Cohorts</span>
            </div>
            <div>
              <span className="text-white font-semibold block">General Enquiries</span>
              <span>admissions@dotrepo.org</span>
            </div>
          </div>
        </div>

        <form onSubmit={handleContactSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Your Name *</label>
            <input
              type="text"
              placeholder="Alex Smith"
              value={contactForm.name}
              onChange={e => setContactForm({ ...contactForm, name: e.target.value })}
              className="w-full bg-[#161616] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Email Address *</label>
            <input
              type="email"
              placeholder="alex@example.com"
              value={contactForm.email}
              onChange={e => setContactForm({ ...contactForm, email: e.target.value })}
              className="w-full bg-[#161616] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Subject</label>
            <input
              type="text"
              placeholder="Cohort inquiry / Hiring Partnership"
              value={contactForm.subject}
              onChange={e => setContactForm({ ...contactForm, subject: e.target.value })}
              className="w-full bg-[#161616] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Your Message *</label>
            <textarea
              rows={4}
              placeholder="Type your message here..."
              value={contactForm.message}
              onChange={e => setContactForm({ ...contactForm, message: e.target.value })}
              className="w-full bg-[#161616] border border-[#2A2A2A] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-white resize-none"
            />
          </div>

          <button
            type="submit"
            disabled={sending}
            className="w-full py-3 bg-white text-black font-bold text-xs rounded-xl hover:bg-neutral-200 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{sending ? 'Sending...' : 'Send Message'}</span>
          </button>
        </form>

      </section>

      {/* FAQS SECTION */}
      <section className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0]">Knowledge Base</span>
          <h2 className="text-3xl font-extrabold text-white">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-3">
          {FAQ_ITEMS.map((faq) => {
            const isOpen = openFaq === faq.id;
            return (
              <div
                key={faq.id}
                className="bg-[#161616] border border-[#2A2A2A] rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : faq.id)}
                  className="w-full p-4 text-left flex items-center justify-between text-xs font-bold text-white hover:text-neutral-200"
                >
                  <span>{faq.question}</span>
                  <ChevronDown className={`w-4 h-4 text-[#A0A0A0] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 text-xs text-[#A0A0A0] leading-relaxed border-t border-[#2A2A2A]/50 pt-3">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
};
