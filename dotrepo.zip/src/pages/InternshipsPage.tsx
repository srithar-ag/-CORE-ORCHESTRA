import React, { useState, useEffect } from 'react';
import { Search, Briefcase, RotateCcw, X } from 'lucide-react';
import { Internship, Domain } from '../types';
import { InternshipCard } from '../components/InternshipCard';

interface InternshipsPageProps {
  onApplyInternship: (internship: Internship) => void;
}

const DOMAINS: Domain[] = [
  'All',
  'React',
  'Artificial Intelligence',
  'Backend',
  'UI UX',
  'Node.js',
  'Python',
  'Cyber Security',
  'DevOps'
];

export const InternshipsPage: React.FC<InternshipsPageProps> = ({ onApplyInternship }) => {
  const [internships, setInternships] = useState<Internship[]>([]);
  const [loading, setLoading] = useState(true);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<Domain>('All');
  const [selectedDuration, setSelectedDuration] = useState<string>('All');

  useEffect(() => {
    fetchInternships();
  }, [selectedDomain, selectedDuration, searchQuery]);

  const fetchInternships = async () => {
    setLoading(true);
    try {
      const queryParts = [];
      if (selectedDomain && selectedDomain !== 'All') queryParts.push(`domain=${encodeURIComponent(selectedDomain)}`);
      if (selectedDuration && selectedDuration !== 'All') queryParts.push(`duration=${encodeURIComponent(selectedDuration)}`);
      if (searchQuery) queryParts.push(`search=${encodeURIComponent(searchQuery)}`);

      const queryString = queryParts.length ? `?${queryParts.join('&')}` : '';
      const res = await fetch(`/api/internships${queryString}`);
      const data = await res.json();
      setInternships(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error('Error fetching internships:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setSearchQuery('');
    setSelectedDomain('All');
    setSelectedDuration('All');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Page Header */}
      <div className="space-y-2">
        <span className="text-xs font-semibold uppercase tracking-widest text-[#A0A0A0] flex items-center gap-1.5">
          <Briefcase className="w-4 h-4 text-white" /> Career Track
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">Explore Paid Remote Internships</h1>
        <p className="text-xs sm:text-sm text-[#A0A0A0] max-w-2xl">
          Join DotRepo as an intern. Receive stipend rewards, 1-on-1 performance reviews, and Letters of Recommendation.
        </p>
      </div>

      {/* Filter Bar */}
      <div className="bg-[#111111] border border-[#2A2A2A] rounded-2xl p-4 sm:p-5 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#A0A0A0]" />
            <input
              type="text"
              placeholder="Search by role name, stipend, tech stack..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-[#161616] border border-[#2A2A2A] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-[#666666] focus:outline-none focus:border-white transition-colors"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A0A0A0]">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <select
            value={selectedDuration}
            onChange={e => setSelectedDuration(e.target.value)}
            className="w-full sm:w-auto bg-[#161616] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-white"
          >
            <option value="All">All Durations</option>
            <option value="2 Months">2 Months</option>
            <option value="3 Months">3 Months</option>
          </select>
        </div>

        {/* Domain Filter Pills */}
        <div className="pt-2 border-t border-[#2A2A2A]/60 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-[11px] font-semibold text-[#666666] uppercase tracking-wider shrink-0 pr-2">
            Domain:
          </span>
          {DOMAINS.map(domain => {
            const active = selectedDomain === domain;
            return (
              <button
                key={domain}
                onClick={() => setSelectedDomain(domain)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium shrink-0 border transition-all duration-200 ${
                  active
                    ? 'bg-white text-black border-white font-bold'
                    : 'bg-[#161616] text-[#A0A0A0] border-[#2A2A2A] hover:text-white'
                }`}
              >
                {domain}
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-96 bg-[#161616] rounded-2xl animate-pulse border border-[#2A2A2A]" />
          ))}
        </div>
      ) : internships.length === 0 ? (
        <div className="text-center py-20 bg-[#111111] border border-[#2A2A2A] rounded-2xl space-y-3">
          <Briefcase className="w-12 h-12 text-[#444] mx-auto" />
          <h3 className="text-base font-bold text-white">No Internships Found</h3>
          <p className="text-xs text-[#A0A0A0]">Try adjusting your search criteria or resetting filters.</p>
          <button
            onClick={handleReset}
            className="px-4 py-2 bg-white text-black font-semibold rounded-lg text-xs inline-block mt-2"
          >
            Reset Search
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {internships.map(intern => (
            <InternshipCard key={intern.id} internship={intern} onApply={onApplyInternship} />
          ))}
        </div>
      )}

    </div>
  );
};
