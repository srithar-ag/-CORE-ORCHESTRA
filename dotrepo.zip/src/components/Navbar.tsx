import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Search, Menu, X, User as UserIcon, Shield, Bookmark, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  onOpenSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenSearch }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Projects', path: '/projects' },
    { name: 'Internships', path: '/internships' },
    { name: 'About', path: '/about' },
  ];

  const isActive = (path: string) => {
    if (path === '/' && location.pathname !== '/') return false;
    return location.pathname.startsWith(path);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#000000]/80 backdrop-blur-md border-b border-[#2A2A2A]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand Logo */}
        <Link to="/" className="flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-lg bg-white text-black font-bold flex items-center justify-center text-lg tracking-tight group-hover:scale-105 transition-transform">
            .R
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold tracking-wider text-white flex items-center gap-1">
              DotRepo
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
            </span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-1 bg-[#111111]/80 p-1.5 rounded-full border border-[#2A2A2A]">
          {navLinks.map((link) => {
            const active = isActive(link.path);
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`px-4 py-1.5 text-sm font-medium rounded-full transition-all duration-200 ${
                  active
                    ? 'bg-white text-black shadow-sm font-semibold'
                    : 'text-[#A0A0A0] hover:text-white hover:bg-[#161616]'
                }`}
              >
                {link.name}
              </Link>
            );
          })}
        </nav>

        {/* Right Actions */}
        <div className="hidden md:flex items-center gap-3">
          {/* Global Search Button */}
          <button
            onClick={onOpenSearch}
            className="flex items-center gap-2 px-3 py-1.5 bg-[#111111] hover:bg-[#161616] text-[#A0A0A0] hover:text-white border border-[#2A2A2A] rounded-lg text-xs transition-colors"
            title="Search projects & internships"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Search</span>
            <kbd className="bg-[#161616] border border-[#2A2A2A] text-[10px] px-1.5 py-0.5 rounded text-[#A0A0A0]">
              ⌘K
            </kbd>
          </button>

          {/* Admin Panel Badge if Admin */}
          {isAdmin && (
            <Link
              to="/admin"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#161616] hover:bg-[#222222] text-white border border-[#2A2A2A] rounded-lg text-xs font-medium transition-colors"
            >
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>Admin Panel</span>
            </Link>
          )}

          {/* Profile / Auth Button */}
          {isAuthenticated ? (
            <div className="flex items-center gap-2">
              <Link
                to="/profile"
                className="flex items-center gap-2 px-3 py-1.5 bg-[#161616] hover:bg-[#222222] border border-[#2A2A2A] rounded-lg text-xs text-white font-medium transition-colors"
              >
                {user?.avatar ? (
                  <img src={user.avatar} alt="Avatar" className="w-4 h-4 rounded-full object-cover" />
                ) : (
                  <UserIcon className="w-3.5 h-3.5" />
                )}
                <span>Profile</span>
              </Link>
              <button
                onClick={logout}
                className="p-1.5 text-[#A0A0A0] hover:text-white hover:bg-[#161616] border border-[#2A2A2A] rounded-lg transition-colors"
                title="Sign Out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="px-4 py-1.5 bg-white text-black hover:bg-neutral-200 text-xs font-semibold rounded-lg transition-colors"
            >
              Sign In
            </Link>
          )}
        </div>

        {/* Mobile menu button */}
        <div className="flex md:hidden items-center gap-2">
          <button
            onClick={onOpenSearch}
            className="p-2 text-[#A0A0A0] hover:text-white bg-[#111111] border border-[#2A2A2A] rounded-lg"
          >
            <Search className="w-4 h-4" />
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#A0A0A0] hover:text-white bg-[#111111] border border-[#2A2A2A] rounded-lg"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#000000] border-b border-[#2A2A2A] px-4 pt-2 pb-6 space-y-3">
          <nav className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`px-4 py-2 text-sm font-medium rounded-lg ${
                  isActive(link.path)
                    ? 'bg-white text-black font-semibold'
                    : 'text-[#A0A0A0] hover:bg-[#111111] hover:text-white'
                }`}
              >
                {link.name}
              </Link>
            ))}
            {isAdmin && (
              <Link
                to="/admin"
                onClick={() => setMobileMenuOpen(false)}
                className="px-4 py-2 text-sm font-medium text-emerald-400 bg-[#161616] rounded-lg flex items-center gap-2"
              >
                <Shield className="w-4 h-4" />
                Admin Panel
              </Link>
            )}
          </nav>

          <div className="pt-2 border-t border-[#2A2A2A] flex items-center justify-between">
            {isAuthenticated ? (
              <div className="flex items-center justify-between w-full">
                <Link
                  to="/profile"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-2 text-sm text-white font-medium"
                >
                  <UserIcon className="w-4 h-4" />
                  Profile Dashboard
                </Link>
                <button
                  onClick={() => {
                    logout();
                    setMobileMenuOpen(false);
                  }}
                  className="text-xs text-[#A0A0A0] hover:text-white px-2 py-1 border border-[#2A2A2A] rounded"
                >
                  Logout
                </button>
              </div>
            ) : (
              <Link
                to="/login"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full text-center py-2 bg-white text-black font-semibold rounded-lg text-sm"
              >
                Sign In
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
