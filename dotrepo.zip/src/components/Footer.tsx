import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Github, Linkedin, Twitter, Mail, ShieldCheck } from 'lucide-react';
import { useToast } from '../context/ToastContext';

export const Footer: React.FC = () => {
  const { showToast } = useToast();
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      showToast('Please enter a valid email address', '', 'error');
      return;
    }
    showToast('Subscribed to DotRepo Dispatch!', 'You will receive monthly product updates and internship drops.', 'success');
    setEmail('');
  };

  return (
    <footer className="bg-[#000000] border-t border-[#2A2A2A] text-[#A0A0A0] text-sm pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-[#2A2A2A]">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-white text-black font-bold flex items-center justify-center text-lg">
                .R
              </div>
              <span className="text-xl font-bold tracking-wider text-white">DotRepo</span>
            </Link>

            <p className="text-[#A0A0A0] text-sm max-w-sm leading-relaxed">
              Designing and Building Products for Meaningful Real-World Impact. Join thousands of engineers mastering industry software development.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-lg bg-[#111111] hover:bg-[#161616] border border-[#2A2A2A] flex items-center justify-center text-[#A0A0A0] hover:text-white transition-colors"
                aria-label="GitHub"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-lg bg-[#111111] hover:bg-[#161616] border border-[#2A2A2A] flex items-center justify-center text-[#A0A0A0] hover:text-white transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-lg bg-[#111111] hover:bg-[#161616] border border-[#2A2A2A] flex items-center justify-center text-[#A0A0A0] hover:text-white transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-4">Navigation</h4>
            <ul className="space-y-2.5 text-xs">
              <li><Link to="/" className="hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/projects" className="hover:text-white transition-colors">Explore Projects</Link></li>
              <li><Link to="/internships" className="hover:text-white transition-colors">Explore Internships</Link></li>
              <li><Link to="/about" className="hover:text-white transition-colors">About & Team</Link></li>
              <li><Link to="/profile" className="hover:text-white transition-colors">Student Dashboard</Link></li>
            </ul>
          </div>

          {/* Core Domains */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-4">Popular Domains</h4>
            <ul className="space-y-2.5 text-xs">
              <li><Link to="/projects?domain=Artificial+Intelligence" className="hover:text-white transition-colors">Artificial Intelligence</Link></li>
              <li><Link to="/projects?domain=Machine+Learning" className="hover:text-white transition-colors">Machine Learning</Link></li>
              <li><Link to="/projects?domain=MERN" className="hover:text-white transition-colors">Full-Stack MERN</Link></li>
              <li><Link to="/projects?domain=DevOps" className="hover:text-white transition-colors">DevOps & Cloud</Link></li>
              <li><Link to="/projects?domain=Cyber+Security" className="hover:text-white transition-colors">Cyber Security</Link></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-4">Stay Updated</h4>
            <p className="text-xs text-[#A0A0A0] mb-3 leading-relaxed">
              Get notified when new high-impact industry projects and remote internships launch.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="relative">
                <input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#111111] border border-[#2A2A2A] rounded-lg px-3 py-2 text-xs text-white placeholder-[#555555] focus:outline-none focus:border-white transition-colors pr-9"
                />
                <button
                  type="submit"
                  className="absolute right-1 top-1 bottom-1 px-2 bg-white text-black hover:bg-neutral-200 rounded text-xs transition-colors flex items-center justify-center"
                  aria-label="Subscribe"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#666666] gap-4">
          <p>© 2026 DotRepo Inc. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-[#888888]">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Verified Credentials Engine
            </span>
            <span>Privacy Policy</span>
            <span>Terms of Service</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
