import React from 'react';
import { Link } from 'react-router-dom';
import { Internship } from '../types';
import { Bookmark, Building2, Calendar, MapPin, Award, FileCheck, ArrowRight, UserCheck } from 'lucide-react';
import { useBookmarks } from '../context/BookmarkContext';

interface InternshipCardProps {
  internship: Internship;
  onApply?: (internship: Internship) => void;
}

export const InternshipCard: React.FC<InternshipCardProps> = ({ internship, onApply }) => {
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const bookmarked = isBookmarked(internship.id);

  return (
    <div className="group relative bg-[#161616] hover:bg-[#1c1c1c] border border-[#2A2A2A] hover:border-white/40 rounded-2xl p-6 flex flex-col justify-between transition-all duration-300 shadow-lg">
      
      <div>
        {/* Header Header Info */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-white text-black font-bold flex items-center justify-center text-lg shrink-0 border border-white">
              .R
            </div>
            <div>
              <span className="text-xs text-[#A0A0A0] font-medium tracking-wide flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-white" /> {internship.company}
              </span>
              <Link to={`/internships/${internship.id}`}>
                <h3 className="text-base font-bold text-white group-hover:text-neutral-200 transition-colors line-clamp-1">
                  {internship.role}
                </h3>
              </Link>
            </div>
          </div>

          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              toggleBookmark(internship.id);
            }}
            className="p-2 rounded-full bg-[#111111] hover:bg-[#222222] border border-[#2A2A2A] text-white transition-colors"
            title={bookmarked ? 'Remove Bookmark' : 'Bookmark Internship'}
          >
            <Bookmark className={`w-3.5 h-3.5 ${bookmarked ? 'fill-white' : ''}`} />
          </button>
        </div>

        {/* Overview text */}
        <p className="text-xs text-[#A0A0A0] mt-3 line-clamp-2 leading-relaxed">
          {internship.overview}
        </p>

        {/* Highlights Row */}
        <div className="grid grid-cols-3 gap-2 mt-4 text-xs bg-[#111111] p-3 rounded-xl border border-[#2A2A2A]/60 text-center">
          <div>
            <span className="block text-[10px] text-[#666] uppercase tracking-wider">Stipend</span>
            <span className="text-white font-semibold text-xs mt-0.5 block">{internship.stipend}</span>
          </div>
          <div className="border-x border-[#2A2A2A]/60 px-1">
            <span className="block text-[10px] text-[#666] uppercase tracking-wider">Duration</span>
            <span className="text-white font-semibold text-xs mt-0.5 block">{internship.duration}</span>
          </div>
          <div>
            <span className="block text-[10px] text-[#666] uppercase tracking-wider">Openings</span>
            <span className="text-white font-semibold text-xs mt-0.5 block">{internship.openings} Seats</span>
          </div>
        </div>

        {/* Requirements snippet */}
        <div className="mt-4 space-y-1.5">
          <span className="text-[11px] font-semibold text-[#A0A0A0] uppercase tracking-wider">Key Requirements</span>
          <ul className="text-xs text-[#A0A0A0] space-y-1">
            {internship.requirements.slice(0, 2).map((req, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="w-1 h-1 rounded-full bg-white mt-1.5 shrink-0" />
                <span className="line-clamp-1">{req}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Tech Stack Tags */}
        <div className="flex flex-wrap gap-1.5 mt-4">
          {internship.techStack.map((tech) => (
            <span
              key={tech}
              className="bg-[#111111] text-white/80 text-[10px] px-2 py-0.5 rounded border border-[#2A2A2A]"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>

      {/* Footer Benefits & Actions */}
      <div className="mt-6 pt-4 border-t border-[#2A2A2A] flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs">
          {internship.hasCertificate && (
            <span className="flex items-center gap-1 text-emerald-400 font-medium text-[11px]">
              <Award className="w-3.5 h-3.5" /> Certificate
            </span>
          )}
          {internship.hasLOR && (
            <span className="flex items-center gap-1 text-purple-400 font-medium text-[11px]">
              <FileCheck className="w-3.5 h-3.5" /> LOR
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Link
            to={`/internships/${internship.id}`}
            className="px-3 py-1.5 bg-[#111111] hover:bg-[#222222] text-xs font-semibold text-white rounded-lg border border-[#2A2A2A] transition-colors"
          >
            Role Details
          </Link>
          <button
            onClick={() => onApply && onApply(internship)}
            className="px-3.5 py-1.5 bg-white hover:bg-neutral-200 text-black text-xs font-bold rounded-lg transition-colors flex items-center gap-1"
          >
            <span>Apply</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

    </div>
  );
};
