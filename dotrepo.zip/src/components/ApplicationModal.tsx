import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { X, Check, ArrowRight, ArrowLeft, Upload, Sparkles, CheckCircle2, ShieldAlert } from 'lucide-react';
import { useToast } from '../context/ToastContext';

interface ApplicationModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetItem: { id: string; name: string; type: 'Project' | 'Internship'; domain: string } | null;
}

export const ApplicationModal: React.FC<ApplicationModalProps> = ({
  isOpen,
  onClose,
  targetItem,
}) => {
  const { showToast } = useToast();
  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [submittedRef, setSubmittedRef] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    // Step 1: Personal
    fullName: '',
    email: '',
    phone: '',
    dob: '',
    gender: 'Male',
    address: '',

    // Step 2: Education
    college: '',
    university: '',
    degree: 'B.S. Computer Science',
    department: 'Computer Science',
    year: 'Final Year (2026)',
    cgpa: '',

    // Step 3: Skills
    programmingLanguages: ['Python', 'JavaScript', 'TypeScript'] as string[],
    frameworks: ['React', 'Node.js', 'Tailwind CSS'] as string[],
    databases: ['MongoDB', 'PostgreSQL'] as string[],
    tools: ['Git', 'Docker'] as string[],
    softSkills: ['Problem Solving', 'Teamwork', 'Communication'] as string[],

    // Step 4: Experience
    projectsExperience: '',
    internshipsExperience: '',
    githubUrl: '',
    linkedinUrl: '',
    portfolioUrl: '',
    resumeFileName: '',

    // Step 5: Questions
    whyJoin: '',
    whySelectYou: '',
    careerGoals: '',
    availability: 'Immediate (15-20 hrs/week)',
    declarationAccepted: false,
  });

  if (!isOpen || !targetItem) return null;

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayToggle = (category: string, item: string) => {
    const arr = (formData[category as keyof typeof formData] as string[]) || [];
    if (arr.includes(item)) {
      handleChange(
        category,
        arr.filter(i => i !== item)
      );
    } else {
      handleChange(category, [...arr, item]);
    }
  };

  const validateStep = () => {
    if (step === 1) {
      if (!formData.fullName || !formData.email || !formData.phone) {
        showToast('Required fields missing', 'Please fill in Full Name, Email, and Phone Number.', 'error');
        return false;
      }
    }
    if (step === 2) {
      if (!formData.college || !formData.cgpa) {
        showToast('Required fields missing', 'Please enter College Name and CGPA.', 'error');
        return false;
      }
    }
    if (step === 4) {
      if (!formData.githubUrl) {
        showToast('GitHub Profile URL required', 'Please provide your GitHub profile link.', 'error');
        return false;
      }
    }
    if (step === 5) {
      if (!formData.whyJoin || !formData.declarationAccepted) {
        showToast('Accept declaration', 'Please complete the motivation answer and check the declaration.', 'error');
        return false;
      }
    }
    return true;
  };

  const handleNext = () => {
    if (validateStep()) {
      setStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    setStep(prev => Math.max(1, prev - 1));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep()) return;

    setSubmitting(true);
    try {
      const payload = {
        ...formData,
        itemId: targetItem.id,
        itemTitle: targetItem.name,
        itemType: targetItem.type,
        domain: targetItem.domain,
      };

      const res = await fetch('/api/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      setSubmitting(false);

      if (data.success) {
        setSubmittedRef(data.referenceId);
        // Fire celebration confetti
        try {
          confetti({
            particleCount: 120,
            spread: 80,
            origin: { y: 0.6 },
            colors: ['#ffffff', '#a0a0a0', '#444444'],
          });
        } catch (err) {
          // fallback if confetti fails
        }
        showToast('Application Submitted!', `Reference ID: ${data.referenceId}`, 'success');
      } else {
        showToast('Submission Failed', 'Please try again or check server state.', 'error');
      }
    } catch (err) {
      setSubmitting(false);
      showToast('Error Submitting', 'Connection error. Please try again.', 'error');
    }
  };

  // Skill Options Arrays
  const langOpts = ['Python', 'Java', 'JavaScript', 'TypeScript', 'C++', 'Go', 'Rust', 'Kotlin'];
  const fwOpts = ['React', 'Next.js', 'Node.js', 'Express', 'PyTorch', 'Tailwind CSS', 'FastAPI', 'Docker'];
  const dbOpts = ['MongoDB', 'PostgreSQL', 'Redis', 'ChromaDB', 'MySQL'];
  const softOpts = ['Problem Solving', 'Leadership', 'Teamwork', 'Communication', 'Adaptability'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-3xl bg-[#161616] border border-[#2A2A2A] rounded-2xl shadow-2xl overflow-hidden my-8 text-white flex flex-col">
        
        {/* Header Bar */}
        <div className="p-5 bg-[#111111] border-b border-[#2A2A2A] flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase tracking-widest text-[#A0A0A0] font-semibold">
              Applying for {targetItem.type}
            </span>
            <h3 className="text-base font-bold text-white mt-0.5">{targetItem.name}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#A0A0A0] hover:text-white bg-[#161616] border border-[#2A2A2A] rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Screen if submitted */}
        {submittedRef ? (
          <div className="p-8 sm:p-12 text-center space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 text-white flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10 text-emerald-400" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-white tracking-tight">
                Application Submitted Successfully!
              </h2>
              <p className="text-sm text-[#A0A0A0] max-w-md mx-auto">
                Thank you for applying to <span className="text-white font-semibold">{targetItem.name}</span>. Our evaluation panel is reviewing your profile.
              </p>
            </div>

            {/* Reference ID Card */}
            <div className="bg-[#111111] border border-[#2A2A2A] p-4 rounded-xl max-w-md mx-auto space-y-1">
              <span className="text-xs text-[#A0A0A0] uppercase tracking-wider block">Application Reference Code</span>
              <span className="text-2xl font-mono font-bold text-white tracking-widest block select-all">
                {submittedRef}
              </span>
              <span className="text-[11px] text-[#888888]">Save this code to track your status live on your Profile Dashboard.</span>
            </div>

            <div className="pt-4 flex items-center justify-center gap-3">
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-white text-black font-bold rounded-xl text-sm hover:bg-neutral-200 transition-colors"
              >
                Close Window
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Steps Progress Indicator */}
            <div className="px-6 pt-4 pb-2 bg-[#111111]/50 border-b border-[#2A2A2A] flex items-center justify-between text-xs text-[#A0A0A0]">
              {[1, 2, 3, 4, 5].map(s => (
                <div key={s} className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center font-bold transition-colors ${
                      step === s
                        ? 'bg-white text-black'
                        : step > s
                        ? 'bg-white/20 text-white'
                        : 'bg-[#222222] text-[#666]'
                    }`}
                  >
                    {step > s ? <Check className="w-3.5 h-3.5" /> : s}
                  </div>
                  <span className={`hidden sm:inline ${step === s ? 'text-white font-semibold' : ''}`}>
                    {s === 1 && 'Personal'}
                    {s === 2 && 'Education'}
                    {s === 3 && 'Skills'}
                    {s === 4 && 'Experience'}
                    {s === 5 && 'Declaration'}
                  </span>
                </div>
              ))}
            </div>

            {/* Form Step Contents */}
            <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[65vh] overflow-y-auto">
              
              {/* STEP 1: Personal Info */}
              {step === 1 && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                    Step 1: Personal Information
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Full Name *</label>
                      <input
                        type="text"
                        placeholder="John Doe"
                        value={formData.fullName}
                        onChange={e => handleChange('fullName', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Email Address *</label>
                      <input
                        type="email"
                        placeholder="john@example.com"
                        value={formData.email}
                        onChange={e => handleChange('email', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Phone Number *</label>
                      <input
                        type="tel"
                        placeholder="+1 (555) 000-0000"
                        value={formData.phone}
                        onChange={e => handleChange('phone', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Date of Birth</label>
                      <input
                        type="date"
                        value={formData.dob}
                        onChange={e => handleChange('dob', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Gender</label>
                      <select
                        value={formData.gender}
                        onChange={e => handleChange('gender', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      >
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Non-binary">Non-binary</option>
                        <option value="Prefer not to say">Prefer not to say</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">City / Address</label>
                      <input
                        type="text"
                        placeholder="San Francisco, CA"
                        value={formData.address}
                        onChange={e => handleChange('address', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 2: Education */}
              {step === 2 && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                    Step 2: Educational Qualifications
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">College Name *</label>
                      <input
                        type="text"
                        placeholder="Stanford University"
                        value={formData.college}
                        onChange={e => handleChange('college', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">University / Board</label>
                      <input
                        type="text"
                        placeholder="Stanford Board of Regents"
                        value={formData.university}
                        onChange={e => handleChange('university', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Degree</label>
                      <input
                        type="text"
                        placeholder="B.Tech / B.S. Computer Science"
                        value={formData.degree}
                        onChange={e => handleChange('degree', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Department</label>
                      <input
                        type="text"
                        placeholder="Computer Science & Engineering"
                        value={formData.department}
                        onChange={e => handleChange('department', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Graduation Year</label>
                      <select
                        value={formData.year}
                        onChange={e => handleChange('year', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      >
                        <option value="1st Year (2029)">1st Year (2029)</option>
                        <option value="2nd Year (2028)">2nd Year (2028)</option>
                        <option value="3rd Year (2027)">3rd Year (2027)</option>
                        <option value="Final Year (2026)">Final Year (2026)</option>
                        <option value="Recent Graduate">Recent Graduate</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">CGPA / Percentage *</label>
                      <input
                        type="text"
                        placeholder="3.85 / 10.0"
                        value={formData.cgpa}
                        onChange={e => handleChange('cgpa', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 3: Skills */}
              {step === 3 && (
                <div className="space-y-5 animate-in fade-in duration-200">
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                    Step 3: Technical & Soft Skills
                  </h4>

                  <div>
                    <label className="block text-xs font-semibold text-[#A0A0A0] mb-2">Programming Languages</label>
                    <div className="flex flex-wrap gap-2">
                      {langOpts.map(item => {
                        const sel = formData.programmingLanguages.includes(item);
                        return (
                          <button
                            type="button"
                            key={item}
                            onClick={() => handleArrayToggle('programmingLanguages', item)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                              sel
                                ? 'bg-white text-black border-white font-semibold'
                                : 'bg-[#111111] text-[#A0A0A0] border-[#2A2A2A] hover:text-white'
                            }`}
                          >
                            {item}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#A0A0A0] mb-2">Frameworks & Libraries</label>
                    <div className="flex flex-wrap gap-2">
                      {fwOpts.map(item => {
                        const sel = formData.frameworks.includes(item);
                        return (
                          <button
                            type="button"
                            key={item}
                            onClick={() => handleArrayToggle('frameworks', item)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                              sel
                                ? 'bg-white text-black border-white font-semibold'
                                : 'bg-[#111111] text-[#A0A0A0] border-[#2A2A2A] hover:text-white'
                            }`}
                          >
                            {item}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#A0A0A0] mb-2">Databases</label>
                    <div className="flex flex-wrap gap-2">
                      {dbOpts.map(item => {
                        const sel = formData.databases.includes(item);
                        return (
                          <button
                            type="button"
                            key={item}
                            onClick={() => handleArrayToggle('databases', item)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                              sel
                                ? 'bg-white text-black border-white font-semibold'
                                : 'bg-[#111111] text-[#A0A0A0] border-[#2A2A2A] hover:text-white'
                            }`}
                          >
                            {item}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#A0A0A0] mb-2">Soft Skills</label>
                    <div className="flex flex-wrap gap-2">
                      {softOpts.map(item => {
                        const sel = formData.softSkills.includes(item);
                        return (
                          <button
                            type="button"
                            key={item}
                            onClick={() => handleArrayToggle('softSkills', item)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                              sel
                                ? 'bg-white text-black border-white font-semibold'
                                : 'bg-[#111111] text-[#A0A0A0] border-[#2A2A2A] hover:text-white'
                            }`}
                          >
                            {item}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 4: Experience & Links */}
              {step === 4 && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                    Step 4: Experience & Portfolio
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">GitHub Profile *</label>
                      <input
                        type="url"
                        placeholder="https://github.com/yourusername"
                        value={formData.githubUrl}
                        onChange={e => handleChange('githubUrl', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">LinkedIn Profile</label>
                      <input
                        type="url"
                        placeholder="https://linkedin.com/in/yourprofile"
                        value={formData.linkedinUrl}
                        onChange={e => handleChange('linkedinUrl', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Portfolio Website</label>
                      <input
                        type="url"
                        placeholder="https://yourportfolio.dev"
                        value={formData.portfolioUrl}
                        onChange={e => handleChange('portfolioUrl', e.target.value)}
                        className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                      />
                    </div>
                  </div>

                  {/* Resume Upload Box */}
                  <div>
                    <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Upload Resume (PDF)</label>
                    <div className="border-2 border-dashed border-[#2A2A2A] hover:border-white/50 rounded-2xl p-6 text-center cursor-pointer bg-[#111111] transition-colors">
                      <Upload className="w-8 h-8 text-[#A0A0A0] mx-auto mb-2" />
                      <p className="text-xs text-white font-medium">
                        {formData.resumeFileName
                          ? `Uploaded: ${formData.resumeFileName}`
                          : 'Drag and drop your PDF resume, or click to browse'}
                      </p>
                      <p className="text-[10px] text-[#666] mt-1">Maximum size: 10MB</p>
                      <input
                        type="file"
                        accept=".pdf"
                        onChange={e => {
                          if (e.target.files && e.target.files[0]) {
                            handleChange('resumeFileName', e.target.files[0].name);
                          }
                        }}
                        className="hidden"
                        id="resume-upload"
                      />
                      <label
                        htmlFor="resume-upload"
                        className="inline-block mt-3 px-3 py-1.5 bg-[#222222] hover:bg-[#2A2A2A] text-white text-xs rounded-lg cursor-pointer"
                      >
                        Choose File
                      </label>
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 5: Motivation & Declaration */}
              {step === 5 && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                    Step 5: Motivation & Declaration
                  </h4>

                  <div>
                    <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">
                      Why do you want to join DotRepo? *
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Share your passion for engineering and building real products..."
                      value={formData.whyJoin}
                      onChange={e => handleChange('whyJoin', e.target.value)}
                      className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-white resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">
                      Why should we select you over other applicants?
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Highlight relevant projects, problem-solving mindset..."
                      value={formData.whySelectYou}
                      onChange={e => handleChange('whySelectYou', e.target.value)}
                      className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-white resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#A0A0A0] mb-1">Weekly Availability</label>
                    <select
                      value={formData.availability}
                      onChange={e => handleChange('availability', e.target.value)}
                      className="w-full bg-[#111111] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                    >
                      <option value="10-15 hrs/week">10-15 hrs/week</option>
                      <option value="15-20 hrs/week">15-20 hrs/week</option>
                      <option value="20-30 hrs/week">20-30 hrs/week</option>
                      <option value="Full Time (40 hrs/week)">Full Time (40 hrs/week)</option>
                    </select>
                  </div>

                  {/* Declaration Checkbox */}
                  <div className="pt-2">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.declarationAccepted}
                        onChange={e => handleChange('declarationAccepted', e.target.checked)}
                        className="mt-1 rounded bg-[#111111] border-[#2A2A2A] text-white focus:ring-0"
                      />
                      <span className="text-xs text-[#A0A0A0] leading-relaxed">
                        I hereby declare that all information provided in this application is accurate and true to the best of my knowledge. I agree to DotRepo’s code of conduct and review policies.
                      </span>
                    </label>
                  </div>
                </div>
              )}

              {/* Navigation Controls */}
              <div className="pt-4 border-t border-[#2A2A2A] flex items-center justify-between">
                {step > 1 ? (
                  <button
                    type="button"
                    onClick={handleBack}
                    className="px-4 py-2 bg-[#111111] hover:bg-[#222222] text-white text-xs font-semibold rounded-xl border border-[#2A2A2A] transition-colors flex items-center gap-1.5"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" /> Back
                  </button>
                ) : <div />}

                {step < 5 ? (
                  <button
                    type="button"
                    onClick={handleNext}
                    className="px-5 py-2 bg-white text-black font-bold text-xs rounded-xl hover:bg-neutral-200 transition-colors flex items-center gap-1.5"
                  >
                    <span>Next Step</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={submitting}
                    className="px-6 py-2.5 bg-white text-black font-bold text-xs rounded-xl hover:bg-neutral-200 transition-colors disabled:opacity-50 flex items-center gap-2"
                  >
                    {submitting ? 'Submitting Application...' : 'Submit Application'}
                  </button>
                )}
              </div>

            </form>
          </>
        )}

      </div>
    </div>
  );
};
