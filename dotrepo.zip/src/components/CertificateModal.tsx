import React, { useState } from 'react';
import { X, ShieldCheck, Download, ExternalLink, Sparkles } from 'lucide-react';
import { Certificate } from '../types';

interface CertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  certificate: Certificate | null;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({
  isOpen,
  onClose,
  certificate,
}) => {
  if (!isOpen || !certificate) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="w-full max-w-2xl bg-[#161616] border border-[#2A2A2A] rounded-2xl shadow-2xl overflow-hidden text-white flex flex-col">
        
        {/* Header */}
        <div className="p-4 bg-[#111111] border-b border-[#2A2A2A] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span className="text-sm font-bold text-white">Verified Credential</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#A0A0A0] hover:text-white bg-[#161616] border border-[#2A2A2A] rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Certificate Display Canvas */}
        <div className="p-8 bg-[#000000] border-y border-[#2A2A2A] m-4 rounded-xl relative overflow-hidden text-center space-y-6">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex justify-between items-center border-b border-[#2A2A2A] pb-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded bg-white text-black font-bold flex items-center justify-center text-xs">
                .R
              </div>
              <span className="font-bold tracking-wider text-sm">DotRepo Studio</span>
            </div>
            <span className="text-[10px] font-mono text-[#A0A0A0] border border-[#2A2A2A] px-2 py-0.5 rounded">
              {certificate.certificateNumber}
            </span>
          </div>

          <div className="space-y-2 py-2">
            <span className="text-xs uppercase tracking-widest text-[#A0A0A0]">Certificate of Completion</span>
            <h2 className="text-xl font-bold text-white">{certificate.title}</h2>
            <p className="text-xs text-[#A0A0A0]">
              This is to certify that <span className="text-white font-semibold underline">{certificate.issuedTo}</span> has successfully completed all required milestones and code reviews in <span className="text-white font-semibold">{certificate.domain}</span>.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-1.5">
            {certificate.skills.map((s) => (
              <span key={s} className="bg-[#111111] border border-[#2A2A2A] text-[10px] px-2 py-0.5 rounded text-white/80">
                {s}
              </span>
            ))}
          </div>

          <div className="pt-4 border-t border-[#2A2A2A] flex justify-between items-end text-left text-[11px] text-[#888888]">
            <div>
              <span className="block text-[#555] uppercase text-[9px]">Issued On</span>
              <span className="text-white font-mono">{certificate.issueDate}</span>
            </div>
            <div className="text-right">
              <span className="block text-[#555] uppercase text-[9px]">Authority</span>
              <span className="text-white font-semibold">DotRepo Academic Council</span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-[#111111] border-t border-[#2A2A2A] flex items-center justify-between text-xs">
          <a
            href={certificate.verificationUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 text-[#A0A0A0] hover:text-white transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" /> Verify Link
          </a>
          <button
            onClick={() => alert('Certificate PDF Downloaded!')}
            className="px-4 py-2 bg-white text-black font-bold rounded-xl hover:bg-neutral-200 transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" /> Download PDF
          </button>
        </div>

      </div>
    </div>
  );
};
