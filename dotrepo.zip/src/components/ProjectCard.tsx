import React from 'react';
import { Link } from 'react-router-dom';
import { Project } from '../types';
import { Bookmark, Clock, Users, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';
import { useBookmarks } from '../context/BookmarkContext';

interface ProjectCardProps {
  project: Project;
  onApply?: (project: Project) => void;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project, onApply }) => {
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const bookmarked = isBookmarked(project.id);

  return (
    <div className="group relative bg-[#161616] hover:bg-[#1c1c1c] border border-[#2A2A2A] hover:border-white/40 rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 shadow-lg hover:shadow-2xl">
      
      {/* Top Banner / Image & Badges */}
      <div>
        <div className="relative h-44 w-full rounded-xl overflow-hidden mb-4 border border-[#2A2A2A]">
          <img
            src={project.thumbnail}
            alt={project.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#161616] via-transparent to-black/40" />

          {/* Domain & Difficulty Badges */}
          <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 z-10">
            <span className="bg-black/80 backdrop-blur-md text-white text-[11px] font-medium px-2.5 py-1 rounded-full border border-white/20">
              {project.domain}
            </span>
            <span className="bg-[#111111]/90 backdrop-blur-md text-[#A0A0A0] text-[11px] font-medium px-2.5 py-1 rounded-full border border-[#333]">
              {project.difficulty}
            </span>
          </div>

          {/* Bookmark Trigger */}
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              toggleBookmark(project.id);
            }}
            className="absolute top-3 right-3 p-2 rounded-full bg-black/60 hover:bg-black/90 backdrop-blur-md border border-white/20 text-white transition-colors z-10"
            title={bookmarked ? 'Remove Bookmark' : 'Bookmark Project'}
          >
            <Bookmark className={`w-3.5 h-3.5 ${bookmarked ? 'fill-white' : ''}`} />
          </button>
        </div>

        {/* Title & Overview */}
        <Link to={`/projects/${project.id}`}>
          <h3 className="text-base font-bold text-white group-hover:text-neutral-200 transition-colors line-clamp-2 leading-snug">
            {project.name}
          </h3>
        </Link>
        <p className="text-xs text-[#A0A0A0] mt-2 line-clamp-2 leading-relaxed">
          {project.overview}
        </p>

        {/* Key Attributes Grid */}
        <div className="grid grid-cols-2 gap-2 mt-4 text-xs text-[#A0A0A0] bg-[#111111] p-3 rounded-xl border border-[#2A2A2A]/60">
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-white" />
            <span>{project.duration}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-white" />
            <span>{project.teamSize}</span>
          </div>
          <div className="flex items-center gap-1.5 col-span-2 text-[11px]">
            <span className="text-[#666]">Mode:</span>
            <span className="text-white font-medium">{project.mode}</span>
            <span className="mx-1">•</span>
            <span className="text-[#666]">Deadline:</span>
            <span className="text-white font-medium">{project.deadline}</span>
          </div>
        </div>

        {/* Tech Stack Pills */}
        <div className="flex flex-wrap gap-1.5 mt-4">
          {project.techStack.slice(0, 4).map((tech) => (
            <span
              key={tech}
              className="bg-[#111111] text-white/80 text-[10px] px-2 py-0.5 rounded border border-[#2A2A2A]"
            >
              {tech}
            </span>
          ))}
          {project.techStack.length > 4 && (
            <span className="text-[10px] text-[#A0A0A0] self-center">
              +{project.techStack.length - 4} more
            </span>
          )}
        </div>
      </div>

      {/* Card Footer Features & CTA */}
      <div className="mt-5 pt-4 border-t border-[#2A2A2A] flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs">
          {project.hasCertificate && (
            <span className="flex items-center gap-1 text-emerald-400 font-medium text-[11px]">
              <ShieldCheck className="w-3.5 h-3.5" /> Certificate
            </span>
          )}
          {project.isPortfolioProject && (
            <span className="flex items-center gap-1 text-blue-400 font-medium text-[11px]">
              <Sparkles className="w-3.5 h-3.5" /> Portfolio Ready
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Link
            to={`/projects/${project.id}`}
            className="px-3 py-1.5 bg-[#111111] hover:bg-[#222222] text-xs font-semibold text-white rounded-lg border border-[#2A2A2A] transition-colors"
          >
            Details
          </Link>
          <button
            onClick={() => onApply && onApply(project)}
            className="px-3 py-1.5 bg-white hover:bg-neutral-200 text-black text-xs font-bold rounded-lg transition-colors flex items-center gap-1"
          >
            <span>Apply</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

    </div>
  );
};
