import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, X, FolderGit2, Briefcase, ChevronRight, FileText, ArrowUpRight } from 'lucide-react';
import { INITIAL_PROJECTS, INITIAL_INTERNSHIPS } from '../data/initialData';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({ isOpen, onClose }) => {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredProjects = query.trim()
    ? INITIAL_PROJECTS.filter(
        p =>
          p.name.toLowerCase().includes(query.toLowerCase()) ||
          p.domain.toLowerCase().includes(query.toLowerCase()) ||
          p.techStack.some(t => t.toLowerCase().includes(query.toLowerCase()))
      )
    : INITIAL_PROJECTS.slice(0, 3);

  const filteredInternships = query.trim()
    ? INITIAL_INTERNSHIPS.filter(
        i =>
          i.role.toLowerCase().includes(query.toLowerCase()) ||
          i.domain.toLowerCase().includes(query.toLowerCase()) ||
          i.techStack.some(t => t.toLowerCase().includes(query.toLowerCase()))
      )
    : INITIAL_INTERNSHIPS.slice(0, 2);

  const handleSelect = (path: string) => {
    onClose();
    navigate(path);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/80 backdrop-blur-md">
      <div className="w-full max-w-2xl bg-[#161616] border border-[#2A2A2A] rounded-2xl shadow-2xl overflow-hidden flex flex-col text-white animate-in fade-in zoom-in-95 duration-150">
        
        {/* Search Input Bar */}
        <div className="p-4 border-b border-[#2A2A2A] flex items-center gap-3">
          <Search className="w-5 h-5 text-[#A0A0A0]" />
          <input
            type="text"
            autoFocus
            placeholder="Search projects, internships, domains, or skills..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm text-white placeholder-[#666666] focus:outline-none"
          />
          <button
            onClick={onClose}
            className="p-1 text-[#A0A0A0] hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results Body */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-6 divide-y divide-[#2A2A2A]/40">
          
          {/* Projects Section */}
          {filteredProjects.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-[#A0A0A0] uppercase tracking-wider mb-2 flex items-center gap-2">
                <FolderGit2 className="w-3.5 h-3.5 text-white" /> Projects
              </h4>
              <div className="space-y-1">
                {filteredProjects.map(proj => (
                  <button
                    key={proj.id}
                    onClick={() => handleSelect(`/projects/${proj.id}`)}
                    className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-[#222222] transition-colors text-left group"
                  >
                    <div>
                      <h5 className="text-sm font-semibold text-white group-hover:text-emerald-300 transition-colors">
                        {proj.name}
                      </h5>
                      <div className="flex items-center gap-2 mt-1 text-xs text-[#A0A0A0]">
                        <span className="bg-[#222222] px-2 py-0.5 rounded border border-[#333] text-[10px]">
                          {proj.domain}
                        </span>
                        <span>{proj.difficulty}</span>
                        <span>•</span>
                        <span>{proj.duration}</span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#A0A0A0] group-hover:translate-x-1 transition-transform" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Internships Section */}
          {filteredInternships.length > 0 && (
            <div className="pt-4">
              <h4 className="text-xs font-semibold text-[#A0A0A0] uppercase tracking-wider mb-2 flex items-center gap-2">
                <Briefcase className="w-3.5 h-3.5 text-white" /> Internships
              </h4>
              <div className="space-y-1">
                {filteredInternships.map(intern => (
                  <button
                    key={intern.id}
                    onClick={() => handleSelect(`/internships/${intern.id}`)}
                    className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-[#222222] transition-colors text-left group"
                  >
                    <div>
                      <h5 className="text-sm font-semibold text-white group-hover:text-blue-300 transition-colors">
                        {intern.role}
                      </h5>
                      <p className="text-xs text-[#A0A0A0] mt-0.5">
                        {intern.company} • {intern.stipend} • {intern.mode}
                      </p>
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-[#A0A0A0] group-hover:text-white transition-colors" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quick Pages */}
          <div className="pt-4">
            <h4 className="text-xs font-semibold text-[#A0A0A0] uppercase tracking-wider mb-2 flex items-center gap-2">
              <FileText className="w-3.5 h-3.5 text-white" /> Pages
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => handleSelect('/about')}
                className="p-2.5 bg-[#111111] hover:bg-[#222222] border border-[#2A2A2A] rounded-lg text-left text-white"
              >
                About DotRepo
              </button>
              <button
                onClick={() => handleSelect('/profile')}
                className="p-2.5 bg-[#111111] hover:bg-[#222222] border border-[#2A2A2A] rounded-lg text-left text-white"
              >
                Student Profile Dashboard
              </button>
            </div>
          </div>

        </div>

        <div className="p-3 bg-[#111111] border-t border-[#2A2A2A] text-right text-[11px] text-[#A0A0A0]">
          Press <kbd className="bg-[#161616] px-1.5 py-0.5 rounded border border-[#333]">ESC</kbd> to close
        </div>
      </div>
    </div>
  );
};
