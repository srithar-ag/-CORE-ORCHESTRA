export type Domain =
  | 'All'
  | 'Artificial Intelligence'
  | 'Machine Learning'
  | 'Python'
  | 'Java'
  | 'JavaScript'
  | 'React'
  | 'Node.js'
  | 'MERN'
  | 'Frontend'
  | 'Backend'
  | 'Cloud'
  | 'Cyber Security'
  | 'UI UX'
  | 'Data Science'
  | 'Power BI'
  | 'DevOps'
  | 'Blockchain'
  | 'IoT'
  | 'Android'
  | 'Open Source';

export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced';
export type Duration = '1 Week' | '2 Weeks' | '1 Month' | '2 Months' | '3 Months';
export type WorkMode = 'Remote' | 'Hybrid' | 'On-site';

export interface Project {
  id: string;
  name: string;
  domain: Domain;
  difficulty: Difficulty;
  duration: Duration;
  timeline: string;
  mode: WorkMode;
  teamSize: string;
  techStack: string[];
  hasCertificate: boolean;
  isPortfolioProject: boolean;
  deadline: string;
  thumbnail: string;
  overview: string;
  description: string;
  learningOutcomes: string[];
  skillsRequired: string[];
  tasks: { title: string; detail: string; week: number }[];
  mentor: { name: string; title: string; avatar: string; company: string };
  faqs: { question: string; answer: string }[];
  featured?: boolean;
  createdAt: string;
}

export interface Internship {
  id: string;
  company: string;
  role: string;
  domain: Domain;
  duration: Duration;
  mode: WorkMode;
  openings: number;
  stipend: string;
  requirements: string[];
  responsibilities: string[];
  techStack: string[];
  hasCertificate: boolean;
  hasLOR: boolean;
  performanceReview: string;
  selectionProcess: { step: number; title: string; description: string }[];
  deadline: string;
  thumbnail: string;
  overview: string;
  featured?: boolean;
  createdAt: string;
}

export type ApplicationStatus =
  | 'Applied'
  | 'Under Review'
  | 'Shortlisted'
  | 'Scheduled Interview'
  | 'Accepted'
  | 'Rejected';

export interface Application {
  id: string;
  referenceId: string;
  itemType: 'Project' | 'Internship';
  itemId: string;
  itemTitle: string;
  domain: string;
  status: ApplicationStatus;
  appliedAt: string;
  interviewDetails?: {
    date: string;
    time: string;
    link: string;
    notes?: string;
  };
  adminNotes?: string;
  
  // Step 1: Personal
  fullName: string;
  email: string;
  phone: string;
  dob: string;
  gender: string;
  address: string;

  // Step 2: Education
  college: string;
  university: string;
  degree: string;
  department: string;
  year: string;
  cgpa: string;

  // Step 3: Skills
  programmingLanguages: string[];
  frameworks: string[];
  databases: string[];
  tools: string[];
  softSkills: string[];

  // Step 4: Experience
  projectsExperience: string;
  internshipsExperience: string;
  githubUrl: string;
  linkedinUrl: string;
  portfolioUrl: string;
  resumeFileName?: string;

  // Step 5: Questions
  whyJoin: string;
  whySelectYou: string;
  careerGoals: string;
  availability: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
  avatar?: string;
  phone?: string;
  college?: string;
  degree?: string;
  cgpa?: string;
  github?: string;
  linkedin?: string;
  bio?: string;
}

export interface Certificate {
  id: string;
  certificateNumber: string;
  title: string;
  type: 'Project' | 'Internship';
  issuedTo: string;
  domain: string;
  issueDate: string;
  verificationUrl: string;
  skills: string[];
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'application' | 'system' | 'interview' | 'certificate';
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio: string;
  avatar: string;
  linkedin: string;
  github?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  college?: string;
  company?: string;
  avatar: string;
  content: string;
  rating: number;
  companyPlacements?: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category?: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
}
