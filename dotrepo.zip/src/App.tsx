import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { BookmarkProvider } from './context/BookmarkContext';

import { BackgroundGrid } from './components/BackgroundGrid';
import { ProgressBar } from './components/ProgressBar';
import { ScrollToTop } from './components/ScrollToTop';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { ApplicationModal } from './components/ApplicationModal';

import { HomePage } from './pages/HomePage';
import { ProjectsPage } from './pages/ProjectsPage';
import { ProjectDetailsPage } from './pages/ProjectDetailsPage';
import { InternshipsPage } from './pages/InternshipsPage';
import { InternshipDetailsPage } from './pages/InternshipDetailsPage';
import { AboutPage } from './pages/AboutPage';
import { ProfilePage } from './pages/ProfilePage';
import { AdminPage } from './pages/AdminPage';
import { LoginPage } from './pages/LoginPage';
import { NotFoundPage } from './pages/NotFoundPage';

import { Project, Internship } from './types';

function AppContent() {
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  
  // Application Modal state
  const [appModalOpen, setAppModalOpen] = useState(false);
  const [targetItem, setTargetItem] = useState<{
    id: string;
    name: string;
    type: 'Project' | 'Internship';
    domain: string;
  } | null>(null);

  const handleApplyProject = (proj: Project) => {
    setTargetItem({
      id: proj.id,
      name: proj.name,
      type: 'Project',
      domain: proj.domain,
    });
    setAppModalOpen(true);
  };

  const handleApplyInternship = (intern: Internship) => {
    setTargetItem({
      id: intern.id,
      name: `${intern.company} - ${intern.role}`,
      type: 'Internship',
      domain: intern.domain,
    });
    setAppModalOpen(true);
  };

  return (
    <div className="relative min-h-screen bg-[#000000] text-white flex flex-col selection:bg-white selection:text-black">
      {/* Background Interactive Canvas */}
      <BackgroundGrid />

      {/* Top Scroll Progress Line */}
      <ProgressBar />

      {/* Floating Back-To-Top Button */}
      <ScrollToTop />

      {/* Header Navigation */}
      <Navbar onOpenSearch={() => setSearchModalOpen(true)} />

      {/* Main Page Routing */}
      <main className="flex-1 relative z-10">
        <Routes>
          <Route
            path="/"
            element={
              <HomePage
                onApplyProject={handleApplyProject}
                onApplyInternship={handleApplyInternship}
              />
            }
          />
          <Route
            path="/projects"
            element={<ProjectsPage onApplyProject={handleApplyProject} />}
          />
          <Route
            path="/projects/:id"
            element={<ProjectDetailsPage onApplyProject={handleApplyProject} />}
          />
          <Route
            path="/internships"
            element={<InternshipsPage onApplyInternship={handleApplyInternship} />}
          />
          <Route
            path="/internships/:id"
            element={
              <InternshipDetailsPage onApplyInternship={handleApplyInternship} />
            }
          />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>

      {/* Modern Monochrome Footer */}
      <Footer />

      {/* Modals */}
      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
      />

      <ApplicationModal
        isOpen={appModalOpen}
        onClose={() => setAppModalOpen(false)}
        targetItem={targetItem}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <BookmarkProvider>
          <BrowserRouter>
            <AppContent />
          </BrowserRouter>
        </BookmarkProvider>
      </ToastProvider>
    </AuthProvider>
  );
}
